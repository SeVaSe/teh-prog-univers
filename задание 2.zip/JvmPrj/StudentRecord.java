public record StudentRecord(String name, int id) {
    
    public StudentRecord {
        if (name == null || name.isBlank()) {
            throw new IllegalArgumentException("Имя студента не может быть пустым");
        }
        if (id <= 0) {
            throw new IllegalArgumentException("ID студента должен быть положительным числом");
        }
    }
    
    @Override
    public String toString() {
        return String.format("ID: %d, Имя: %s", id, name);
    }
    
    public String getFormattedInfo() {
        return String.format("[Студент #%04d] %s", id, name);
    }
}