import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class Student implements Registrable {
    
    // Базовая информация о студенте
    private final StudentRecord record;
    
    // Текущий статус студента
    private StudentStatus status;
    
    // Время регистрации
    private LocalDateTime registrationTime;
    
    // Время последнего обновления статуса
    private LocalDateTime lastStatusUpdate;
    
    // Счетчик обновлений статуса
    private int statusUpdateCount = 0;
    
    public Student(String name, int id, StudentStatus initialStatus) {
        this.record = new StudentRecord(name, id);
        this.status = initialStatus;
        this.lastStatusUpdate = LocalDateTime.now();
    }
    
    public Student(String name, int id) {
        this(name, id, StudentStatus.INACTIVE);
    }
    
    @Override
    public void register() {
        this.registrationTime = LocalDateTime.now();
        
        System.out.println("\n" + "=".repeat(60));
        System.out.println("РЕГИСТРАЦИЯ СТУДЕНТА");
        System.out.println("=".repeat(60));
        System.out.println("  " + record.getFormattedInfo());
        System.out.println("  Статус: " + status);
        System.out.println("  Время регистрации: " + formatDateTime(registrationTime));
        System.out.println("=".repeat(60) + "\n");
    }
    
    @Important("Critical: Status update required for system consistency")
    public void updateStatus(StudentStatus newStatus) {
        StudentStatus oldStatus = this.status;
        this.status = newStatus;
        this.lastStatusUpdate = LocalDateTime.now();
        this.statusUpdateCount++;
        
        System.out.println("\n" + "-".repeat(60));
        System.out.println("ОБНОВЛЕНИЕ СТАТУСА");
        System.out.println("-".repeat(60));
        System.out.println("  " + record.getFormattedInfo());
        System.out.println("  Предыдущий статус: " + oldStatus);
        System.out.println("  Новый статус:     " + newStatus);
        System.out.println("  Время изменения:  " + formatDateTime(lastStatusUpdate));
        System.out.println("  Количество обновлений: " + statusUpdateCount);
        System.out.println("-".repeat(60) + "\n");
    }
    
    public StudentStatus getStatus() {
        return status;
    }
    
    public StudentRecord getRecord() {
        return record;
    }
    
    public LocalDateTime getRegistrationTime() {
        return registrationTime;
    }
    
    public LocalDateTime getLastStatusUpdate() {
        return lastStatusUpdate;
    }
    
    public int getStatusUpdateCount() {
        return statusUpdateCount;
    }
    
    public boolean isRegistered() {
        return registrationTime != null;
    }

    public boolean isActive() {
        return status == StudentStatus.ACTIVE;
    }
    
    @Override
    public String toString() {
        return String.format(
            "Student{" +
            "record=%s, " +
            "status=%s, " +
            "registered=%s, " +
            "statusUpdates=%d" +
            "}",
            record, status, isRegistered(), statusUpdateCount
        );
    }
    
    private String formatDateTime(LocalDateTime dateTime) {
        if (dateTime == null) return "N/A";
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd.MM.yyyy HH:mm:ss");
        return dateTime.format(formatter);
    }
}
