
public enum StudentStatus {

    ACTIVE("Активен", "✓"),
    
    INACTIVE("Неактивен", "✗"),
    
    SUSPENDED("Приостановлен", "=");
    
    private final String description;
    private final String symbol;
    
    StudentStatus(String description, String symbol) {
        this.description = description;
        this.symbol = symbol;
    }
    
    public String getDescription() {
        return description;
    }
    
    public String getSymbol() {
        return symbol;
    }
    
    @Override
    public String toString() {
        return symbol + " " + description + " (" + this.name() + ")";
    }
}
