import java.lang.reflect.Method;
import java.util.Arrays;

public class Main {
    
    public static void main(String[] args) {
        try {
            displayHeader();
            
            System.out.println("\nЭтап 1: Создание объекта Student");
            System.out.println("-".repeat(60));
            
            Student student = new Student("Иван Иванов", 12345, StudentStatus.INACTIVE);
            System.out.println("Студент создан");
            System.out.println("  " + student);
            
            System.out.println("\nЭтап 2: Регистрация студента");
            student.register();
            
            System.out.println("Этап 3: Информация о студенте");
            System.out.println("-".repeat(60));
            System.out.println("  ID: " + student.getRecord().id());
            System.out.println("  Имя: " + student.getRecord().name());
            System.out.println("  Статус: " + student.getStatus());
            System.out.println("  Активен: " + (student.isActive() ? "Да" : "Нет"));
            System.out.println("  Зарегистрирован: " + (student.isRegistered() ? "Да" : "Нет"));
            
            System.out.println("\nЭтап 4: Обновление статуса");
            student.updateStatus(StudentStatus.ACTIVE);
            System.out.println("  Активен: " + (student.isActive() ? "Да" : "Нет"));
            
            System.out.println("Этап 5: Повторное обновление статуса");
            student.updateStatus(StudentStatus.SUSPENDED);
            
            System.out.println("\nЭтап 6: Анализ аннотаций методов класса Student");
            analyzeAnnotations(Student.class);
            
            System.out.println("\nЭтап 7: Статистика");
            System.out.println("-".repeat(60));
            System.out.println("  Количество обновлений статуса: " + student.getStatusUpdateCount());
            System.out.println("  Время регистрации: " + student.getRegistrationTime());
            System.out.println("  Последнее изменение: " + student.getLastStatusUpdate());
            System.out.println("  Итоговый статус: " + student.getStatus());
            
            System.out.println("\nЭтап 8: Управление несколькими студентами");
            System.out.println("-".repeat(60));
            
            Student[] students = {
                new Student("Мария Петрова", 12346, StudentStatus.ACTIVE),
                new Student("Петр Сидоров", 12347, StudentStatus.INACTIVE),
                new Student("Анна Смирнова", 12348, StudentStatus.SUSPENDED)
            };
            
            System.out.println("Созданы студенты:");
            for (Student s : students) {
                System.out.println("  " + s.getRecord().getFormattedInfo());
            }
            
            System.out.println("\nРегистрация всех студентов:");
            for (Student s : students) {
                s.register();
            }
            
            System.out.println("Обновление статусов:");
            for (int i = 0; i < students.length; i++) {
                StudentStatus newStatus = StudentStatus.values()[(i + 1) % StudentStatus.values().length];
                students[i].updateStatus(newStatus);
            }
            
            displayFooter();
            
        } catch (Exception e) {
            System.err.println("\nОшибка при выполнении: " + e.getMessage());
            e.printStackTrace();
            System.exit(1);
        }
    }
    
    private static void analyzeAnnotations(Class<?> clazz) {
        System.out.println("-".repeat(60));
        System.out.println("Анализ аннотаций @Important:");
        
        Method[] methods = clazz.getDeclaredMethods();
        
        boolean foundAnnotated = false;
        
        for (Method method : methods) {
            if (method.isAnnotationPresent(Important.class)) {
                foundAnnotated = true;
                Important important = method.getAnnotation(Important.class);
                
                System.out.println("\n  Метод: " + method.getName());
                System.out.println("     Аннотация: @Important");
                System.out.println("     Значение: \"" + important.value() + "\"");
                System.out.println("     Возвращаемый тип: " + method.getReturnType().getSimpleName());
                
                Class<?>[] params = method.getParameterTypes();
                if (params.length > 0) {
                    System.out.println("     Параметры: " + Arrays.toString(params));
                } else {
                    System.out.println("     Параметры: нет");
                }
            }
        }
        
        if (!foundAnnotated) {
            System.out.println("\n  Методов с аннотацией @Important не найдено");
        }
        
        System.out.println("\n  Все публичные методы класса:");
        int methodCount = 0;
        for (Method method : methods) {
            if (java.lang.reflect.Modifier.isPublic(method.getModifiers())) {
                methodCount++;
                String annotated = method.isAnnotationPresent(Important.class) ? " [IMPORTANT]" : "";
                System.out.println("     " + methodCount + ". " + method.getName() + annotated);
            }
        }
        
        System.out.println("-".repeat(60));
    }
    
    private static String centerText(String text, int width) {
        if (text.length() >= width) {
            return text;
        }
        int totalPadding = width - text.length();
        int leftPadding = totalPadding / 2;
        int rightPadding = totalPadding - leftPadding;
        return " ".repeat(leftPadding) + text + " ".repeat(rightPadding);
    }
    
    private static void displayHeader() {
        System.out.println("\n" + "=".repeat(60));
        System.out.println("=");
        System.out.println("=" + centerText("СИСТЕМА УПРАВЛЕНИЯ СТУДЕНТАМИ", 58) + "=");
        System.out.println("=" + centerText("(Аннотации и Reflection)", 58) + "=");
        System.out.println("=");
        System.out.println("=".repeat(60));
    }
    
    private static void displayFooter() {
        System.out.println("\n" + "=".repeat(60));
        System.out.println("=" + centerText("ПРОГРАММА УСПЕШНО ЗАВЕРШЕНА", 58) + "=");
        System.out.println("=".repeat(60) + "\n");
    }
}
