@echo off
chcp 65001 > nul

echo.
echo ==============================================================
echo  МНОГОПОТОЧНАЯ СИСТЕМА УВЕДОМЛЕНИЙ
echo  Сборка и запуск
echo ==============================================================
echo.

:: поменять на свой путь к джаве
set JAVA_HOME=D:\Work\UTILS\Java\jdk-21
if not exist "%JAVA_HOME%" (
    echo Ошибка: JDK не найден в %JAVA_HOME%
    exit /b 1
)

echo [1/2] Компиляция Java-классов...
javac -encoding UTF-8 ^
    NotificationThread.java ^
    NotificationSystem.java ^
    Main.java

if errorlevel 1 goto error
echo Java-классы успешно скомпилированы
echo.

echo [2/2] Запуск программы...
echo.
java Main

if errorlevel 1 goto error
echo.
echo Программа завершена успешно!
exit /b 0

:error
echo.
echo Ошибка при сборке!
exit /b 1