// Главный класс для запуска системы уведомлений
public class Main {
    
    public static void main(String[] args) {
        long programStartTime = System.currentTimeMillis();
        
        try {
            // Создание и запуск системы уведомлений
            NotificationSystem system = new NotificationSystem();
            system.startNotificationSystem();
            
            // Ожидание завершения всех потоков
            system.waitForCompletion();
            long totalTimeMillis = System.currentTimeMillis() - programStartTime;
            long totalTimeSeconds = totalTimeMillis / 1000;
            
            System.out.println("ПРОГРАММА ЗАВЕРШЕНА");
            System.out.printf("Общее время работы: %d секунд\n", totalTimeSeconds);
            System.out.println("Все потоки успешно завершили работу");
            
        } catch (Exception e) {
            System.err.println("Критическая ошибка: " + e.getMessage());
            e.printStackTrace();
        }
    }
}