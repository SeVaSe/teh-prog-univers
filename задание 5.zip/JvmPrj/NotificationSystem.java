// Система управления потоками уведомлений
public class NotificationSystem {
    private Thread thread1;
    private Thread thread2;
    private Thread thread3;
    
    private static final long PROGRAM_DURATION = 60000;
    
    // Инициализация и запуск всех потоков
    public void startNotificationSystem() {
        System.out.println("МНОГОПОТОЧНАЯ СИСТЕМА УВЕДОМЛЕНИЙ");
        System.out.println("Программа будет работать 60 секунд\n");
        
        // Создание первого потока (выполняется каждые 5 секунд)
        thread1 = new NotificationThread(
            "ПОТОК 1",
            5,
            "Сообщение времени",
            PROGRAM_DURATION
        );
        
        // Создание второго потока (выполняется каждые 7 секунд)
        thread2 = new NotificationThread(
            "ПОТОК 2",
            7,
            "Служебное уведомление: Проверка состояния системы",
            PROGRAM_DURATION
        );
        
        // Создание третьего потока (выполняется каждые 10 секунд)
        thread3 = new NotificationThread(
            "ПОТОК 3",
            10,
            "Мониторинг: всё стабильно",
            PROGRAM_DURATION
        );
        
        // Установка приоритета потоков
        thread1.setPriority(Thread.NORM_PRIORITY);
        thread2.setPriority(Thread.NORM_PRIORITY);
        thread3.setPriority(Thread.NORM_PRIORITY);
        
        // Запуск всех потоков
        thread1.start();
        thread2.start();
        thread3.start();
        
        System.out.println("Все потоки запущены\n");
    }
    
    // Ожидание завершения всех потоков
    public void waitForCompletion() {
        try {
            thread1.join();
            thread2.join();
            thread3.join();
            
        } catch (InterruptedException e) {
            System.err.println("Ошибка при ожидании потоков: " + e.getMessage());
            Thread.currentThread().interrupt();
        }
    }
    
    // Проверка, работают ли потоки
    public boolean areThreadsAlive() {
        return thread1.isAlive() || thread2.isAlive() || thread3.isAlive();
    }
}
