// Поток для выполнения задач с определённой периодичностью
public class NotificationThread extends Thread {
    private String threadName;
    private int intervalSeconds;
    private String message;
    private long startTime;
    private long durationMillis;
    
    // Конструктор потока уведомлений
    public NotificationThread(String threadName, int intervalSeconds, String message, long durationMillis) {
        this.threadName = threadName;
        this.intervalSeconds = intervalSeconds;
        this.message = message;
        this.durationMillis = durationMillis;
        this.startTime = System.currentTimeMillis();
    }
    
    @Override
    public void run() {
        long currentTime = System.currentTimeMillis();
        
        // Цикл продолжается, пока не истечёт время программы
        while (currentTime - startTime < durationMillis) {
            try {
                long elapsedSeconds = (currentTime - startTime) / 1000;
                
                System.out.printf("[%s] Время: %d сек | %s\n", 
                    threadName, elapsedSeconds, message);
                
                Thread.sleep(intervalSeconds * 1000);
                
            } catch (InterruptedException e) {
                System.out.println("[" + threadName + "] Поток прерван");
                Thread.currentThread().interrupt();
                break;
            }
            
            currentTime = System.currentTimeMillis();
        }
        
        System.out.printf("[%s] Завершение работы потока\n", threadName);
    }
}