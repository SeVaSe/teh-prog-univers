package app.calculators;

import app.calculators.AuthService.UserAccount;
import app.calculators.CalculatorService.ExchangeRate;
import app.calculators.CalculatorService.HistoryEntry;
import javafx.application.Application;
import javafx.collections.FXCollections;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.Tab;
import javafx.scene.control.TabPane;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.sql.SQLException;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public final class CalculatorsApp extends Application {
    private static final DateTimeFormatter DATE_FORMAT = DateTimeFormatter.ofPattern("dd.MM.yyyy HH:mm:ss");

    private Stage stage;
    private Database database;
    private AuthService authService;
    private CalculatorService calculatorService;
    private UserAccount currentUser;
    private TableView<HistoryEntry> historyTable;

    @Override
    public void start(Stage primaryStage) {
        stage = primaryStage;
        stage.setTitle("Калькуляторы — валюта и закон Ома");
        try {
            database = new Database();
            authService = new AuthService(database);
            calculatorService = new CalculatorService(database);
            if (authService.hasAdministrator()) {
                showAuthentication();
            } else {
                showInitialAdminSetup();
            }
            stage.show();
        } catch (Exception exception) {
            showError("Не удалось запустить приложение", exception);
            stage.close();
        }
    }

    private void showInitialAdminSetup() {
        TextField username = new TextField();
        username.setPromptText("Например, admin");
        PasswordField password = new PasswordField();
        password.setPromptText("Не менее 8 символов");
        PasswordField confirmation = new PasswordField();
        confirmation.setPromptText("Повторите пароль");
        Button createButton = primaryButton("Создать администратора");
        createButton.setOnAction(event -> {
            String cleanUsername = username.getText().trim();
            char[] secret = password.getText().toCharArray();
            try {
                validateUsername(cleanUsername);
                validatePassword(secret);
                if (!password.getText().equals(confirmation.getText())) {
                    throw new IllegalArgumentException("Пароли не совпадают.");
                }
                authService.createInitialAdministrator(cleanUsername, secret);
                showInfo("Администратор создан. Войдите, используя заданные имя и пароль.");
                showAuthentication();
            } catch (Exception exception) {
                showError("Не удалось создать администратора", exception);
            } finally {
                java.util.Arrays.fill(secret, '\0');
                password.clear();
                confirmation.clear();
            }
        });

        VBox form = new VBox(14,
                heading("Первый запуск"),
                muted("Создайте учётную запись администратора. Пароль будет храниться в защищённом виде."),
                labeledField("Имя пользователя", username),
                labeledField("Пароль", password),
                labeledField("Подтверждение пароля", confirmation),
                createButton);
        showCentered(form);
    }

    private void showAuthentication() {
        TextField loginName = new TextField();
        PasswordField loginPassword = new PasswordField();
        Button loginButton = primaryButton("Войти");
        loginButton.setOnAction(event -> {
            char[] secret = loginPassword.getText().toCharArray();
            try {
                UserAccount account = authService.authenticate(loginName.getText().trim(), secret);
                if (account == null) {
                    throw new IllegalArgumentException("Неверное имя пользователя или пароль.");
                }
                currentUser = account;
                showDashboard();
            } catch (Exception exception) {
                showError("Не удалось войти", exception);
            } finally {
                java.util.Arrays.fill(secret, '\0');
                loginPassword.clear();
            }
        });

        VBox loginForm = new VBox(12,
                labeledField("Имя пользователя", loginName),
                labeledField("Пароль", loginPassword),
                loginButton);

        TextField registerName = new TextField();
        registerName.setPromptText("От 3 до 40 символов");
        PasswordField registerPassword = new PasswordField();
        PasswordField registerConfirmation = new PasswordField();
        Button registerButton = primaryButton("Создать аккаунт");
        registerButton.setOnAction(event -> {
            String cleanUsername = registerName.getText().trim();
            char[] secret = registerPassword.getText().toCharArray();
            try {
                validateUsername(cleanUsername);
                validatePassword(secret);
                if (!registerPassword.getText().equals(registerConfirmation.getText())) {
                    throw new IllegalArgumentException("Пароли не совпадают.");
                }
                authService.register(cleanUsername, secret);
                showInfo("Аккаунт создан. Теперь можно войти.");
                loginName.setText(cleanUsername);
                loginPassword.clear();
            } catch (Exception exception) {
                showError("Не удалось создать аккаунт", exception);
            } finally {
                java.util.Arrays.fill(secret, '\0');
                registerPassword.clear();
                registerConfirmation.clear();
            }
        });

        VBox registerForm = new VBox(12,
                labeledField("Имя пользователя", registerName),
                labeledField("Пароль", registerPassword),
                labeledField("Подтверждение пароля", registerConfirmation),
                registerButton);

        TabPane choices = new TabPane(
                new Tab("Вход", loginForm),
                new Tab("Регистрация", registerForm));
        choices.getTabs().forEach(tab -> tab.setClosable(false));
        VBox form = new VBox(14, heading("Добро пожаловать"), choices);
        showCentered(form);
    }

    private void showDashboard() throws SQLException {
        Label accountLabel = muted("Вы вошли как " + currentUser.username()
                + (currentUser.isAdministrator() ? " · администратор" : ""));
        Button logoutButton = new Button("Выйти");
        logoutButton.getStyleClass().add("secondary-button");
        logoutButton.setOnAction(event -> {
            currentUser = null;
            showAuthentication();
        });
        HBox header = new HBox(accountLabel, logoutButton);
        header.setAlignment(Pos.CENTER_LEFT);
        header.setSpacing(12);
        HBox.setHgrow(accountLabel, javafx.scene.layout.Priority.ALWAYS);

        TabPane tabs = new TabPane();
        tabs.getTabs().add(createCurrencyTab());
        tabs.getTabs().add(createOhmTab());
        tabs.getTabs().add(createHistoryTab());
        if (currentUser.isAdministrator()) {
            tabs.getTabs().add(createRatesTab());
        }

        BorderPane layout = new BorderPane(tabs);
        layout.setTop(header);
        BorderPane.setMargin(header, new Insets(0, 0, 16, 0));
        layout.setPadding(new Insets(24));
        showScene(layout, 960, 700);
    }

    private Tab createCurrencyTab() throws SQLException {
        List<ExchangeRate> rates = calculatorService.getRates();
        ComboBox<ExchangeRate> from = new ComboBox<>(FXCollections.observableArrayList(rates));
        ComboBox<ExchangeRate> to = new ComboBox<>(FXCollections.observableArrayList(rates));
        from.getSelectionModel().select(findRate(rates, "USD"));
        to.getSelectionModel().select(findRate(rates, "EUR"));
        TextField amount = new TextField();
        amount.setPromptText("Сумма");
        Label result = resultLabel();

        Button convertButton = primaryButton("Конвертировать");
        convertButton.setOnAction(event -> {
            try {
                BigDecimal value = positiveDecimal(amount.getText(), "Сумма");
                ExchangeRate source = requireSelection(from.getValue(), "Выберите исходную валюту.");
                ExchangeRate target = requireSelection(to.getValue(), "Выберите целевую валюту.");
                BigDecimal converted = calculatorService.convert(
                        currentUser.username(), value, source.code(), target.code());
                result.setText(value.stripTrailingZeros().toPlainString() + " " + source.code()
                        + " = " + converted.setScale(4, RoundingMode.HALF_UP).stripTrailingZeros().toPlainString()
                        + " " + target.code());
                refreshHistory();
            } catch (Exception exception) {
                showError("Не удалось выполнить конвертацию", exception);
            }
        });
        Button refreshButton = new Button("Обновить курсы");
        refreshButton.getStyleClass().add("secondary-button");
        refreshButton.setOnAction(event -> {
            try {
                List<ExchangeRate> latest = calculatorService.getRates();
                from.setItems(FXCollections.observableArrayList(latest));
                to.setItems(FXCollections.observableArrayList(latest));
                from.getSelectionModel().select(findRate(latest, "USD"));
                to.getSelectionModel().select(findRate(latest, "EUR"));
            } catch (Exception exception) {
                showError("Не удалось обновить курсы", exception);
            }
        });

        GridPane fields = formGrid();
        fields.addRow(0, fieldLabel("Сумма"), amount);
        fields.addRow(1, fieldLabel("Из валюты"), from);
        fields.addRow(2, fieldLabel("В валюту"), to);
        VBox content = new VBox(18,
                heading("Конвертер валют"),
                muted("Формула: сумма ÷ курс исходной валюты × курс целевой валюты. Курсы заданы в единицах валюты за 1 USD."),
                fields,
                new HBox(10, convertButton, refreshButton),
                result);
        content.setPadding(new Insets(24, 8, 8, 8));
        return new Tab("Валюта", content);
    }

    private Tab createOhmTab() {
        ComboBox<String> unknown = new ComboBox<>(
                FXCollections.observableArrayList("Напряжение V (вольты)", "Ток I (амперы)", "Сопротивление R (омы)"));
        unknown.getSelectionModel().selectFirst();
        TextField voltage = new TextField();
        voltage.setPromptText("V — оставьте пустым, если вычисляете V");
        TextField current = new TextField();
        current.setPromptText("I — оставьте пустым, если вычисляете I");
        TextField resistance = new TextField();
        resistance.setPromptText("R — оставьте пустым, если вычисляете R");
        Label result = resultLabel();

        unknown.setOnAction(event -> {
            voltage.clear();
            current.clear();
            resistance.clear();
            result.setText("");
        });
        Button calculateButton = primaryButton("Вычислить и сохранить");
        calculateButton.setOnAction(event -> {
            try {
                char variable = switch (unknown.getSelectionModel().getSelectedIndex()) {
                    case 0 -> 'V';
                    case 1 -> 'I';
                    case 2 -> 'R';
                    default -> throw new IllegalArgumentException("Выберите, какую величину вычислить.");
                };
                Double v = optionalPositiveDouble(voltage.getText(), "Напряжение V");
                Double i = optionalPositiveDouble(current.getText(), "Ток I");
                Double r = optionalPositiveDouble(resistance.getText(), "Сопротивление R");
                List<String> missing = new ArrayList<>();
                if (v == null) missing.add("V");
                if (i == null) missing.add("I");
                if (r == null) missing.add("R");
                if (missing.size() != 1 || !missing.getFirst().equals(String.valueOf(variable))) {
                    throw new IllegalArgumentException(
                            "Оставьте пустым только поле " + variable + " и заполните две остальные величины.");
                }
                double calculated = calculatorService.calculateOhm(
                        currentUser.username(), String.valueOf(variable), v, i, r);
                String unit = switch (variable) {
                    case 'V' -> "В";
                    case 'I' -> "А";
                    case 'R' -> "Ом";
                    default -> throw new IllegalStateException("Неизвестная величина.");
                };
                result.setText(String.format(java.util.Locale.ROOT, "%c = %.8g %s", variable, calculated, unit));
                refreshHistory();
            } catch (Exception exception) {
                showError("Не удалось выполнить расчёт", exception);
            }
        });

        GridPane fields = formGrid();
        fields.addRow(0, fieldLabel("Что вычислить"), unknown);
        fields.addRow(1, fieldLabel("Напряжение V (В)"), voltage);
        fields.addRow(2, fieldLabel("Ток I (А)"), current);
        fields.addRow(3, fieldLabel("Сопротивление R (Ом)"), resistance);
        VBox content = new VBox(18,
                heading("Калькулятор закона Ома"),
                muted("Введите любые две положительные величины. Третью выберите в списке и оставьте её поле пустым."),
                fields,
                calculateButton,
                result);
        content.setPadding(new Insets(24, 8, 8, 8));
        return new Tab("Закон Ома", content);
    }

    private Tab createHistoryTab() throws SQLException {
        historyTable = new TableView<>(
                FXCollections.observableArrayList(calculatorService.getHistory(currentUser.username())));
        historyTable.setColumnResizePolicy(TableView.CONSTRAINED_RESIZE_POLICY_ALL_COLUMNS);
        historyTable.getColumns().add(historyColumn("Время", entry -> DATE_FORMAT.format(entry.createdAt()), 160));
        historyTable.getColumns().add(historyColumn("Операция", HistoryEntry::type, 120));
        historyTable.getColumns().add(historyColumn("Входные данные", HistoryEntry::details, 250));
        historyTable.getColumns().add(historyColumn("Результат", HistoryEntry::result, 180));
        Button refresh = new Button("Обновить историю");
        refresh.getStyleClass().add("secondary-button");
        refresh.setOnAction(event -> refreshHistory(historyTable));
        VBox content = new VBox(16, heading("История ваших вычислений"), refresh, historyTable);
        content.setPadding(new Insets(18, 8, 8, 8));
        VBox.setVgrow(historyTable, javafx.scene.layout.Priority.ALWAYS);
        return new Tab("История", content);
    }

    private Tab createRatesTab() throws SQLException {
        TableView<ExchangeRate> table = new TableView<>(
                FXCollections.observableArrayList(calculatorService.getRates()));
        table.setColumnResizePolicy(TableView.CONSTRAINED_RESIZE_POLICY_ALL_COLUMNS);
        table.getColumns().add(rateColumn("Код", ExchangeRate::code, 70));
        table.getColumns().add(rateColumn("Валюта", ExchangeRate::name, 180));
        table.getColumns().add(rateColumn("Единиц за 1 USD", rate -> rate.unitsPerUsd().stripTrailingZeros().toPlainString(), 150));
        table.getColumns().add(rateColumn("Изменил", ExchangeRate::updatedBy, 120));
        table.getColumns().add(rateColumn("Время изменения", rate -> DATE_FORMAT.format(rate.updatedAt()), 160));

        TextField code = new TextField();
        code.setPromptText("USD, EUR, RUB...");
        TextField name = new TextField();
        name.setPromptText("Название валюты");
        TextField rate = new TextField();
        rate.setPromptText("Количество единиц за 1 USD");
        Button save = primaryButton("Сохранить курс");
        save.setOnAction(event -> {
            try {
                String currencyCode = code.getText().trim().toUpperCase(Locale.ROOT);
                if (!currencyCode.matches("[A-Z]{3}")) {
                    throw new IllegalArgumentException("Код валюты должен состоять из трёх латинских букв.");
                }
                String currencyName = name.getText().trim();
                if (currencyName.isEmpty() || currencyName.length() > 60) {
                    throw new IllegalArgumentException("Укажите название валюты длиной от 1 до 60 символов.");
                }
                BigDecimal units = positiveDecimal(rate.getText(), "Курс");
                calculatorService.saveRate(currentUser.username(), currencyCode, currencyName, units);
                table.setItems(FXCollections.observableArrayList(calculatorService.getRates()));
                showInfo("Курс " + currencyCode + " сохранён.");
            } catch (Exception exception) {
                showError("Не удалось сохранить курс", exception);
            }
        });
        GridPane fields = formGrid();
        fields.addRow(0, fieldLabel("Код (ISO, 3 буквы)"), code);
        fields.addRow(1, fieldLabel("Название"), name);
        fields.addRow(2, fieldLabel("Единиц за 1 USD"), rate);
        VBox content = new VBox(16,
                heading("Управление курсами валют"),
                muted("Введите число единиц валюты за 1 USD. Курсы сохраняются в базе данных; курс USD зафиксирован на уровне 1."),
                table,
                fields,
                save);
        content.setPadding(new Insets(18, 8, 8, 8));
        return new Tab("Курсы (администратор)", content);
    }

    private void refreshHistory() {
        if (historyTable != null) {
            refreshHistory(historyTable);
        }
    }

    private void refreshHistory(TableView<HistoryEntry> table) {
        try {
            table.setItems(FXCollections.observableArrayList(calculatorService.getHistory(currentUser.username())));
        } catch (Exception exception) {
            showError("Не удалось обновить историю", exception);
        }
    }

    private TableColumn<HistoryEntry, String> historyColumn(
            String title, java.util.function.Function<HistoryEntry, String> value, double width) {
        TableColumn<HistoryEntry, String> column = new TableColumn<>(title);
        column.setCellValueFactory(cell -> new javafx.beans.property.SimpleStringProperty(value.apply(cell.getValue())));
        column.setPrefWidth(width);
        return column;
    }

    private TableColumn<ExchangeRate, String> rateColumn(
            String title, java.util.function.Function<ExchangeRate, String> value, double width) {
        TableColumn<ExchangeRate, String> column = new TableColumn<>(title);
        column.setCellValueFactory(cell -> new javafx.beans.property.SimpleStringProperty(value.apply(cell.getValue())));
        column.setPrefWidth(width);
        return column;
    }

    private void showCentered(VBox content) {
        content.setMaxWidth(440);
        content.setPadding(new Insets(30));
        content.setAlignment(Pos.CENTER_LEFT);
        BorderPane root = new BorderPane(content);
        root.setPadding(new Insets(24));
        showScene(root, 560, 620);
    }

    private void showScene(Parent root, double width, double height) {
        Scene scene = new Scene(root, width, height);
        var stylesheet = getClass().getResource("/app/calculators/app.css");
        if (stylesheet != null) {
            scene.getStylesheets().add(stylesheet.toExternalForm());
        }
        stage.setScene(scene);
        stage.setMinWidth(Math.min(width, 480));
        stage.setMinHeight(Math.min(height, 400));
    }

    private static GridPane formGrid() {
        GridPane grid = new GridPane();
        grid.setHgap(14);
        grid.setVgap(14);
        return grid;
    }

    private static VBox labeledField(String label, Node field) {
        return new VBox(6, fieldLabel(label), field);
    }

    private static Label fieldLabel(String text) {
        Label label = new Label(text);
        label.getStyleClass().add("field-label");
        return label;
    }

    private static Label heading(String text) {
        Label label = new Label(text);
        label.getStyleClass().add("heading");
        return label;
    }

    private static Label muted(String text) {
        Label label = new Label(text);
        label.getStyleClass().add("muted");
        label.setWrapText(true);
        return label;
    }

    private static Label resultLabel() {
        Label label = new Label();
        label.getStyleClass().add("result");
        label.setWrapText(true);
        return label;
    }

    private static Button primaryButton(String text) {
        Button button = new Button(text);
        button.getStyleClass().add("primary-button");
        return button;
    }

    private static ExchangeRate findRate(List<ExchangeRate> rates, String code) {
        return rates.stream().filter(rate -> rate.code().equals(code)).findFirst().orElse(null);
    }

    private static ExchangeRate requireSelection(ExchangeRate rate, String message) {
        if (rate == null) {
            throw new IllegalArgumentException(message);
        }
        return rate;
    }

    private static BigDecimal positiveDecimal(String text, String label) {
        if (text == null || text.isBlank()) {
            throw new IllegalArgumentException("Введите значение: " + label + ".");
        }
        try {
            BigDecimal number = new BigDecimal(text.trim().replace(',', '.'));
            if (number.signum() <= 0) {
                throw new IllegalArgumentException(label + " должно быть больше нуля.");
            }
            return number;
        } catch (NumberFormatException exception) {
            throw new IllegalArgumentException(label + " должно быть числом.", exception);
        }
    }

    private static Double optionalPositiveDouble(String text, String label) {
        if (text == null || text.isBlank()) {
            return null;
        }
        double value;
        try {
            value = Double.parseDouble(text.trim().replace(',', '.'));
        } catch (NumberFormatException exception) {
            throw new IllegalArgumentException(label + " должно быть числом.", exception);
        }
        if (!Double.isFinite(value) || value <= 0) {
            throw new IllegalArgumentException(label + " должно быть положительным конечным числом.");
        }
        return value;
    }

    private static void validateUsername(String username) {
        if (!username.matches("[A-Za-z0-9_.-]{3,40}")) {
            throw new IllegalArgumentException(
                    "Имя пользователя: 3–40 символов; разрешены латинские буквы, цифры, точка, дефис и подчёркивание.");
        }
    }

    private static void validatePassword(char[] password) {
        if (password.length < 8 || password.length > 128) {
            throw new IllegalArgumentException("Пароль должен содержать от 8 до 128 символов.");
        }
    }

    private void showInfo(String message) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("Готово");
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }

    private void showError(String title, Exception exception) {
        String message = exception.getMessage();
        if (exception instanceof SQLException sqlException
                && sqlException.getSQLState() != null
                && sqlException.getSQLState().startsWith("23")) {
            message = "Такое имя пользователя или код валюты уже существует.";
        }
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle("Ошибка");
        alert.setHeaderText(title);
        alert.setContentText(message == null ? exception.getClass().getSimpleName() : message);
        alert.showAndWait();
    }

    @Override
    public void stop() {
        if (database != null) {
            try (var connection = database.open(); var statement = connection.createStatement()) {
                statement.execute("SHUTDOWN");
            } catch (SQLException exception) {
                System.err.println("Не удалось закрыть базу данных корректно: " + exception.getMessage());
            }
        }
    }

    public static void main(String[] args) {
        launch(args);
    }
}
