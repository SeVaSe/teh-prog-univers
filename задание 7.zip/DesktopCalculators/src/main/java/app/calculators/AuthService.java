package app.calculators;

import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.PBEKeySpec;
import java.security.GeneralSecurityException;
import java.security.MessageDigest;
import java.security.SecureRandom;
import java.sql.SQLException;

final class AuthService {
    private static final int ITERATIONS = 210_000;
    private static final int KEY_LENGTH_BITS = 256;
    private static final SecureRandom RANDOM = new SecureRandom();
    private final Database database;

    AuthService(Database database) {
        this.database = database;
    }

    boolean hasAdministrator() throws SQLException {
        try (var connection = database.open();
             var statement = connection.prepareStatement("SELECT COUNT(*) FROM users WHERE role = 'ADMIN'");
             var result = statement.executeQuery()) {
            result.next();
            return result.getInt(1) > 0;
        }
    }

    void createInitialAdministrator(String username, char[] password) throws SQLException {
        try (var connection = database.open()) {
            connection.setAutoCommit(false);
            try (var statement = connection.prepareStatement("SELECT COUNT(*) FROM users WHERE role = 'ADMIN'");
                 var result = statement.executeQuery()) {
                result.next();
                if (result.getInt(1) > 0) {
                    throw new IllegalStateException("Администратор уже создан.");
                }
            }
            insertUser(connection, username, password, "ADMIN");
            connection.commit();
        }
    }

    void register(String username, char[] password) throws SQLException {
        try (var connection = database.open()) {
            insertUser(connection, username, password, "USER");
        }
    }

    UserAccount authenticate(String username, char[] password) throws SQLException {
        try (var connection = database.open();
             var statement = connection.prepareStatement(
                     "SELECT id, username, password_salt, password_hash, role FROM users WHERE username = ?")) {
            statement.setString(1, username);
            try (var result = statement.executeQuery()) {
                if (!result.next()) {
                    return null;
                }
                byte[] candidate = hash(password, result.getBytes("password_salt"));
                if (!MessageDigest.isEqual(candidate, result.getBytes("password_hash"))) {
                    return null;
                }
                return new UserAccount(
                        result.getLong("id"),
                        result.getString("username"),
                        result.getString("role"));
            }
        }
    }

    private void insertUser(java.sql.Connection connection, String username, char[] password, String role)
            throws SQLException {
        byte[] salt = new byte[16];
        RANDOM.nextBytes(salt);
        try (var statement = connection.prepareStatement(
                "INSERT INTO users (username, password_salt, password_hash, role) VALUES (?, ?, ?, ?)")) {
            statement.setString(1, username);
            statement.setBytes(2, salt);
            statement.setBytes(3, hash(password, salt));
            statement.setString(4, role);
            statement.executeUpdate();
        }
    }

    private byte[] hash(char[] password, byte[] salt) {
        PBEKeySpec specification = new PBEKeySpec(password, salt, ITERATIONS, KEY_LENGTH_BITS);
        try {
            return SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256")
                    .generateSecret(specification)
                    .getEncoded();
        } catch (GeneralSecurityException exception) {
            throw new IllegalStateException("Не удалось защитить пароль.", exception);
        } finally {
            specification.clearPassword();
        }
    }

    record UserAccount(long id, String username, String role) {
        boolean isAdministrator() {
            return "ADMIN".equals(role);
        }
    }
}
