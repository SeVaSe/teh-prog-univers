package app.calculators;

import java.math.BigDecimal;
import java.math.MathContext;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

final class CalculatorService {
    private static final MathContext MATH_CONTEXT = MathContext.DECIMAL128;
    private final Database database;

    CalculatorService(Database database) {
        this.database = database;
    }

    List<ExchangeRate> getRates() throws SQLException {
        List<ExchangeRate> rates = new ArrayList<>();
        try (var connection = database.open();
             var statement = connection.prepareStatement(
                     "SELECT currency_code, currency_name, units_per_usd, updated_at, updated_by " +
                             "FROM exchange_rates ORDER BY currency_code");
             var result = statement.executeQuery()) {
            while (result.next()) {
                rates.add(new ExchangeRate(
                        result.getString("currency_code").trim(),
                        result.getString("currency_name"),
                        result.getBigDecimal("units_per_usd"),
                        result.getTimestamp("updated_at").toLocalDateTime(),
                        result.getString("updated_by")));
            }
        }
        return rates;
    }

    BigDecimal convert(String username, BigDecimal amount, String from, String to) throws SQLException {
        try (var connection = database.open()) {
            connection.setAutoCommit(false);
            BigDecimal fromRate = getRate(connection, from);
            BigDecimal toRate = getRate(connection, to);
            BigDecimal converted = amount.divide(fromRate, MATH_CONTEXT)
                    .multiply(toRate, MATH_CONTEXT);
            String details = amount.stripTrailingZeros().toPlainString() + " " + from + " → " + to;
            saveOperation(connection, username, "Валюта", details,
                    converted.setScale(4, java.math.RoundingMode.HALF_UP).stripTrailingZeros().toPlainString() + " " + to);
            connection.commit();
            return converted;
        }
    }

    double calculateOhm(String username, String unknown, Double voltage, Double current, Double resistance)
            throws SQLException {
        double calculated = switch (unknown) {
            case "V" -> current * resistance;
            case "I" -> voltage / resistance;
            case "R" -> voltage / current;
            default -> throw new IllegalArgumentException("Неизвестная величина для расчёта.");
        };
        if (!Double.isFinite(calculated) || calculated <= 0) {
            throw new IllegalArgumentException("Результат должен быть положительным конечным числом.");
        }

        String details = switch (unknown) {
            case "V" -> String.format(Locale.ROOT, "I = %s A, R = %s Ω", current, resistance);
            case "I" -> String.format(Locale.ROOT, "V = %s V, R = %s Ω", voltage, resistance);
            case "R" -> String.format(Locale.ROOT, "V = %s V, I = %s A", voltage, current);
            default -> throw new IllegalArgumentException("Неизвестная величина для расчёта.");
        };
        String unit = switch (unknown) {
            case "V" -> "V";
            case "I" -> "A";
            case "R" -> "Ω";
            default -> throw new IllegalArgumentException("Неизвестная величина для расчёта.");
        };
        try (var connection = database.open()) {
            saveOperation(connection, username, "Закон Ома", details,
                    String.format(Locale.ROOT, "%s = %.8g %s", unknown, calculated, unit));
        }
        return calculated;
    }

    void saveRate(String username, String code, String name, BigDecimal unitsPerUsd) throws SQLException {
        if ("USD".equals(code) && unitsPerUsd.compareTo(BigDecimal.ONE) != 0) {
            throw new IllegalArgumentException("Курс USD фиксирован: 1 USD = 1 USD.");
        }
        try (var connection = database.open()) {
            connection.setAutoCommit(false);
            try (var statement = connection.prepareStatement("""
                    MERGE INTO exchange_rates (currency_code, currency_name, units_per_usd, updated_at, updated_by)
                    KEY (currency_code) VALUES (?, ?, ?, CURRENT_TIMESTAMP, ?)
                    """)) {
                statement.setString(1, code);
                statement.setString(2, name);
                statement.setBigDecimal(3, unitsPerUsd);
                statement.setString(4, username);
                statement.executeUpdate();
            }
            saveOperation(connection, username, "Курс валюты",
                    code + " — " + name,
                    "1 USD = " + unitsPerUsd.stripTrailingZeros().toPlainString() + " " + code);
            connection.commit();
        }
    }

    List<HistoryEntry> getHistory(String username) throws SQLException {
        List<HistoryEntry> history = new ArrayList<>();
        try (var connection = database.open();
             var statement = connection.prepareStatement("""
                     SELECT operation_type, details, result, created_at
                     FROM operation_history
                     WHERE username = ?
                     ORDER BY created_at DESC, id DESC
                     """)) {
            statement.setString(1, username);
            try (var result = statement.executeQuery()) {
                while (result.next()) {
                    history.add(new HistoryEntry(
                            result.getString("operation_type"),
                            result.getString("details"),
                            result.getString("result"),
                            result.getTimestamp("created_at").toLocalDateTime()));
                }
            }
        }
        return history;
    }

    private BigDecimal getRate(java.sql.Connection connection, String code) throws SQLException {
        try (var statement = connection.prepareStatement(
                "SELECT units_per_usd FROM exchange_rates WHERE currency_code = ?")) {
            statement.setString(1, code);
            try (var result = statement.executeQuery()) {
                if (!result.next()) {
                    throw new IllegalArgumentException("Не найден курс валюты " + code + ".");
                }
                return result.getBigDecimal(1);
            }
        }
    }

    private void saveOperation(java.sql.Connection connection, String username, String type,
                               String details, String result) throws SQLException {
        try (var statement = connection.prepareStatement("""
                INSERT INTO operation_history (username, operation_type, details, result)
                VALUES (?, ?, ?, ?)
                """)) {
            statement.setString(1, username);
            statement.setString(2, type);
            statement.setString(3, details);
            statement.setString(4, result);
            statement.executeUpdate();
        }
    }

    record ExchangeRate(String code, String name, BigDecimal unitsPerUsd,
                        java.time.LocalDateTime updatedAt, String updatedBy) {
        @Override
        public String toString() {
            return code + " — " + name;
        }
    }

    record HistoryEntry(String type, String details, String result, java.time.LocalDateTime createdAt) {
    }
}
