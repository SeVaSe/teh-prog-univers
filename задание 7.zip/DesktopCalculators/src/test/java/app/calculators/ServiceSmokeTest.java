package app.calculators;

import java.math.BigDecimal;
import java.util.Arrays;

public final class ServiceSmokeTest {
    public static void main(String[] args) throws Exception {
        String databaseName = "jdbc:h2:mem:calculator_test;DB_CLOSE_DELAY=-1";
        Database database = new Database(databaseName);
        try {
            AuthService auth = new AuthService(database);
            check(!auth.hasAdministrator(), "A fresh database must need initial admin setup");
            char[] adminPassword = "admin-pass-123".toCharArray();
            auth.createInitialAdministrator("admin", adminPassword);
            Arrays.fill(adminPassword, '\0');
            check(auth.hasAdministrator(), "Initial administrator was not created");
            check(auth.authenticate("admin", "admin-pass-123".toCharArray()).isAdministrator(),
                    "Administrator login failed");
            check(auth.authenticate("admin", "wrong-password".toCharArray()) == null,
                    "Incorrect password must be rejected");
            auth.register("tester", "user-pass-123".toCharArray());

            CalculatorService calculator = new CalculatorService(database);
            BigDecimal converted = calculator.convert("tester", new BigDecimal("10"), "USD", "EUR");
            check(converted.compareTo(new BigDecimal("9.2")) == 0, "Currency conversion is incorrect");
            calculator.saveRate("admin", "GBP", "Британский фунт", new BigDecimal("0.8"));
            check(calculator.getRates().stream().anyMatch(rate -> rate.code().equals("GBP")),
                    "Administrator currency rate was not persisted");
            check(Math.abs(calculator.calculateOhm("tester", "V", null, 2.0, 10.0) - 20.0) < 0.000001,
                    "Voltage calculation is incorrect");
            check(Math.abs(calculator.calculateOhm("tester", "I", 20.0, null, 10.0) - 2.0) < 0.000001,
                    "Current calculation is incorrect");
            check(Math.abs(calculator.calculateOhm("tester", "R", 20.0, 2.0, null) - 10.0) < 0.000001,
                    "Resistance calculation is incorrect");
            check(calculator.getHistory("tester").size() == 4,
                    "Currency and Ohm operations must be saved to user history");
            check(calculator.getHistory("admin").size() == 1
                            && calculator.getHistory("admin").getFirst().type().equals("Курс валюты"),
                    "Administrator currency rate changes must be saved to their history");
            System.out.println("Smoke tests passed: authentication, rates, currency conversion, Ohm's law, history.");
        } finally {
            try (var connection = database.open(); var statement = connection.createStatement()) {
                statement.execute("SHUTDOWN");
            }
        }
    }

    private static void check(boolean condition, String message) {
        if (!condition) {
            throw new AssertionError(message);
        }
    }
}
