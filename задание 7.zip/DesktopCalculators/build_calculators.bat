@echo off
chcp 65001 > nul
setlocal EnableExtensions EnableDelayedExpansion

cd /d "%~dp0"
title JavaFX Calculators

echo.
echo ==============================================================
echo  КАЛЬКУЛЯТОРЫ: ВАЛЮТА И ЗАКОН ОМА
echo  Сборка и запуск JavaFX приложения
echo ==============================================================
echo.

if defined JAVA_HOME if exist "%JAVA_HOME%\bin\javac.exe" set "PATH=%JAVA_HOME%\bin;%PATH%"
where javac.exe > nul 2>&1
if errorlevel 1 (
    echo Ошибка: JDK не найден. Установите JDK 21 или новее и добавьте его в PATH.
    goto failure_without_dependencies
)
where java.exe > nul 2>&1
if errorlevel 1 (
    echo Ошибка: java.exe не найден.
    goto failure_without_dependencies
)
where curl.exe > nul 2>&1
if errorlevel 1 (
    echo Ошибка: curl.exe не найден. Нужен Windows 10/11 или установленный curl.
    goto failure_without_dependencies
)

echo Проверка исходников...
if not exist "src\main\java\app\calculators\CalculatorsApp.java" (
    echo Ошибка: не найден класс приложения.
    goto failure_without_dependencies
)
if not exist "src\main\resources\app\calculators\app.css" (
    echo Ошибка: не найден файл стилей.
    goto failure_without_dependencies
)
echo Исходники найдены
echo.

set "DEPENDENCY_DIR=%TEMP%\DesktopCalculators_%RANDOM%_%RANDOM%"
mkdir "%DEPENDENCY_DIR%"
if errorlevel 1 (
    echo Ошибка: не удалось создать временную папку.
    goto failure_without_dependencies
)

echo Скачивание H2 и JavaFX для Windows...
call :download "com/h2database/h2/2.2.224/h2-2.2.224.jar"
if errorlevel 1 goto dependency_failure
call :download "org/openjfx/javafx-base/21.0.2/javafx-base-21.0.2-win.jar"
if errorlevel 1 goto dependency_failure
call :download "org/openjfx/javafx-graphics/21.0.2/javafx-graphics-21.0.2-win.jar"
if errorlevel 1 goto dependency_failure
call :download "org/openjfx/javafx-controls/21.0.2/javafx-controls-21.0.2-win.jar"
if errorlevel 1 goto dependency_failure
echo Библиотеки загружены
echo.

echo [1/3] Подготовка папки сборки...
if not exist "build\classes" mkdir "build\classes"
if errorlevel 1 goto build_failure
if not exist "build\classes\app\calculators" mkdir "build\classes\app\calculators"
if errorlevel 1 goto build_failure

echo [2/3] Компиляция Java-классов...
javac.exe --release 21 --module-path "%DEPENDENCY_DIR%" --add-modules javafx.controls -cp "%DEPENDENCY_DIR%\h2-2.2.224.jar" -encoding UTF-8 -d "build\classes" ^
    "src\main\java\app\calculators\Database.java" ^
    "src\main\java\app\calculators\AuthService.java" ^
    "src\main\java\app\calculators\CalculatorService.java" ^
    "src\main\java\app\calculators\CalculatorsApp.java"
if errorlevel 1 goto build_failure
copy /y "src\main\resources\app\calculators\app.css" "build\classes\app\calculators\app.css" > nul
if errorlevel 1 goto build_failure
echo Компиляция завершена успешно
echo.

if /i "%~1"=="test" goto run_tests

echo [3/3] Запуск приложения...
java.exe --module-path "%DEPENDENCY_DIR%" --add-modules javafx.controls -cp "build\classes;%DEPENDENCY_DIR%\h2-2.2.224.jar" app.calculators.CalculatorsApp
if errorlevel 1 goto build_failure
goto success

:run_tests
echo [3/3] Запуск тестов логики...
if not exist "src\test\java\app\calculators\ServiceSmokeTest.java" (
    echo Ошибка: тесты не найдены.
    goto build_failure
)
javac.exe --release 21 -cp "build\classes;%DEPENDENCY_DIR%\h2-2.2.224.jar" -encoding UTF-8 -d "build\classes" "src\test\java\app\calculators\ServiceSmokeTest.java"
if errorlevel 1 goto build_failure
java.exe -cp "build\classes;%DEPENDENCY_DIR%\h2-2.2.224.jar" app.calculators.ServiceSmokeTest
if errorlevel 1 goto build_failure
goto success

:download
for %%f in ("%~1") do set "JAR_NAME=%%~nxf"
curl.exe --fail --location --silent --show-error --retry 2 "https://repo.maven.apache.org/maven2/%~1" --output "%DEPENDENCY_DIR%\!JAR_NAME!"
if errorlevel 1 exit /b 1
if not exist "%DEPENDENCY_DIR%\!JAR_NAME!" exit /b 1
for %%f in ("%DEPENDENCY_DIR%\!JAR_NAME!") do if %%~zf LEQ 0 exit /b 1
exit /b 0

:dependency_failure
echo Ошибка загрузки библиотек. Проверьте интернет-соединение.
goto failure

:build_failure
echo Ошибка сборки или запуска приложения.
goto failure

:failure
if defined DEPENDENCY_DIR if exist "%DEPENDENCY_DIR%" rmdir /s /q "%DEPENDENCY_DIR%"
endlocal
pause
exit /b 1

:failure_without_dependencies
endlocal
pause
exit /b 1

:success
if defined DEPENDENCY_DIR if exist "%DEPENDENCY_DIR%" rmdir /s /q "%DEPENDENCY_DIR%"
endlocal
echo.
if /i "%~1"=="test" (
    echo Проверки завершены успешно.
) else (
    echo Приложение закрыто.
)
pause
exit /b 0
