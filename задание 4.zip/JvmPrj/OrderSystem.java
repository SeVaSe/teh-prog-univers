import java.util.ArrayList;
import java.util.List;

// Главный класс системы обработки заказов
public class OrderSystem {
    
    public interface Validatable {
        boolean validate() throws InvalidOrderException;
    }
    
    // Нестатический вложенный класс, представляющий заказ
    public class Order implements Validatable {
        private String productName;
        private int quantity;
        private String status;
        
        public Order(String productName, int quantity) {
            this.productName = productName;
            this.quantity = quantity;
            this.status = "PENDING";
        }
        
        public String getProductName() {
            return productName;
        }
        
        public int getQuantity() {
            return quantity;
        }
        
        public String getStatus() {
            return status;
        }
        
        public void setStatus(String status) {
            this.status = status;
        }
        
        // Валидация заказа с выбросом исключения при ошибке
        @Override
        public boolean validate() throws InvalidOrderException {
            // Проверка пустого названия
            if (productName == null || productName.trim().isEmpty()) {
                throw new InvalidOrderException("Ошибка: название товара не может быть пустым");
            }
            
            if (quantity < 0) {
                throw new InvalidOrderException("Ошибка: количество товара не может быть отрицательным");
            }
            
            if (quantity == 0) {
                throw new InvalidOrderException("Ошибка: количество товара должно быть больше нуля");
            }
            
            return true;
        }
        
        @Override
        public String toString() {
            return String.format("Товар: %-20s | Кол-во: %3d | Статус: %s", 
                    productName, quantity, status);
        }
    }
    
    // Статический вложенный класс для обработки статистики заказов
    public static class OrderStatistics {
        private List<Order> orders;
        private int invalidOrdersCount;
        
        public OrderStatistics(List<Order> orders, int invalidCount) {
            this.orders = orders;
            this.invalidOrdersCount = invalidCount;
        }
        
        // Получить общее количество заказов (валидных + невалидных)
        public int getTotalOrders() {
            return orders.size() + invalidOrdersCount;
        }
        
        // Получить общее количество товаров во всех валидных заказах
        public int getTotalQuantity() {
            int total = 0;
            for (Order order : orders) {
                total += order.getQuantity();
            }
            return total;
        }
        
        // Получить среднее количество товаров на заказ
        public double getAverageQuantity() {
            if (orders.isEmpty()) return 0;
            return (double) getTotalQuantity() / orders.size();
        }
        
        // Получить количество невалидных заказов
        public int getInvalidOrdersCount() {
            return invalidOrdersCount;
        }
        
        // Получить количество валидных заказов
        public int getValidOrdersCount() {
            return orders.size();
        }
    }
}