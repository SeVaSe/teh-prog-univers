import java.util.ArrayList;
import java.util.List;

// Обобщённый класс для хранения элементов любого типа
public class Storage<T> {
    private List<T> items;
    
    public Storage() {
        this.items = new ArrayList<>();
    }
    
    public void addItem(T item) {
        items.add(item);
    }
    
    public T getItem(int index) {
        if (index >= 0 && index < items.size()) {
            return items.get(index);
        }
        return null;
    }
    
    public List<T> getAllItems() {
        return new ArrayList<>(items);
    }
    
    public int getSize() {
        return items.size();
    }
}
