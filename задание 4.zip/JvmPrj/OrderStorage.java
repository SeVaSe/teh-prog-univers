import java.util.List;

// Наследник Storage для хранения заказов
public class OrderStorage extends Storage<OrderSystem.Order> {
    
    // Метод с джокером для работы с подтипами Order
    // Используется для вывода заказов с ограничением типа
    public void printOrders(List<? extends OrderSystem.Order> orders) {
        System.out.println("СПИСОК ЗАКАЗОВ");
        
        if (orders.isEmpty()) {
            System.out.println("Нет заказов для отображения");
        } else {
            for (int i = 0; i < orders.size(); i++) {
                System.out.printf("%d. %s\n", i + 1, orders.get(i));
            }
        }
        
        System.out.println("=".repeat(70));
    }
}
