import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;

// Класс для обработки заказов из файла
public class OrderProcessor {
    public static List<String[]> readOrdersFromFile(String fileName) throws IOException {
        List<String[]> orders = new ArrayList<>();
        
        try (BufferedReader reader = new BufferedReader(new FileReader(fileName))) {
            String line;
            
            while ((line = reader.readLine()) != null) {
                if (line.trim().isEmpty() || line.startsWith("#")) {
                    continue;
                }
                
                String[] parts = line.split(",");
                if (parts.length == 2) {
                    orders.add(parts);
                }
            }
        } catch (IOException e) {
            throw new IOException("Ошибка при чтении файла: " + fileName, e);
        }
        
        return orders;
    }
}
