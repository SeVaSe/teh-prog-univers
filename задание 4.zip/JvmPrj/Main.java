import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class Main {
    
    public static void main(String[] args) {
        try {
            System.out.println("СИСТЕМА ОБРАБОТКИ ЗАКАЗОВ ИНТЕРНЕТ-МАГАЗИНА");
            
            // Этап 1: Создание системы заказов и хранилища
            OrderSystem system = new OrderSystem();
            OrderStorage storage = new OrderStorage();
            
            System.out.println("\nЭтап 1: Инициализация системы");
            System.out.println("- Система заказов создана");
            System.out.println("- Хранилище заказов создано");
            
            // Этап 2: Чтение заказов из файла
            System.out.println("\nЭтап 2: Чтение заказов из файла orders.txt");
            List<String[]> rawOrders = null;
            
            try {
                rawOrders = OrderProcessor.readOrdersFromFile("orders.txt");
                System.out.println("- Прочитано строк из файла: " + rawOrders.size());
            } catch (IOException e) {
                System.err.println("ОШИБКА: " + e.getMessage());
                rawOrders = new ArrayList<>();
            }
            
            // Этап 3: Обработка и валидация заказов
            System.out.println("\nЭтап 3: Валидация и добавление заказов");
            int invalidCount = 0;
            
            for (String[] rawOrder : rawOrders) {
                try {
                    String productName = rawOrder[0].trim();
                    int quantity = Integer.parseInt(rawOrder[1].trim());
                    
                    OrderSystem.Order order = system.new Order(productName, quantity);
                    
                    if (order.validate()) {
                        storage.addItem(order);
                        System.out.println("  Успех: " + order);
                    }
                    
                } catch (InvalidOrderException e) {
                    invalidCount++;
                    System.out.println("  Ошибка валидации: " + e.getMessage());
                    
                } catch (NumberFormatException e) {
                    invalidCount++;
                    System.out.println("  Ошибка формата: Некорректное количество товара");
                    
                } finally {
                }
            }
            
            // Этап 4: Вывод валидных заказов
            System.out.println("\nЭтап 4: Вывод валидных заказов");
            storage.printOrders(storage.getAllItems());
            
            // Этап 5: Обработка статистики
            System.out.println("\nЭтап 5: Статистика заказов");
            OrderSystem.OrderStatistics stats = new OrderSystem.OrderStatistics(
                storage.getAllItems(), 
                invalidCount
            );
            
            System.out.println("СТАТИСТИКА");

            System.out.println("Всего заказов (валидные + невалидные): " + stats.getTotalOrders());
            System.out.println("Валидных заказов: " + stats.getValidOrdersCount());
            System.out.println("Невалидных заказов: " + stats.getInvalidOrdersCount());
            System.out.println("Общее количество товаров: " + stats.getTotalQuantity());
            System.out.printf("Среднее количество товаров на заказ: %.2f\n", stats.getAverageQuantity());
            
            // Демонстрация работы с обобщёнными типами и джокерами
            demonstrateGenerics(storage);
            
            System.out.println("ПРОГРАММА УСПЕШНО ЗАВЕРШЕНА");
            
        } catch (Exception e) {
            System.err.println("\nКритическая ошибка: " + e.getMessage());
            e.printStackTrace();
        }
    }
    
    // Демонстрация работы с обобщёнными типами
    private static void demonstrateGenerics(OrderStorage storage) {
        System.out.println("\nЭтап 6: Демонстрация работы с обобщёнными типами");
        
        // Использование джокеров для работы со списком заказов
        List<? extends OrderSystem.Order> orders = storage.getAllItems();
        
        System.out.println("- Успешно получен список заказов через джокер (? extends Order)");
        System.out.println("- Количество элементов в хранилище: " + orders.size());
        
        System.out.println("- Примечание: instanceof не работает с параметризованными типами");
        
        // Пример создания массива обобщённого типа с подавлением предупреждения
        // @SuppressWarnings подавляет предупреждение о непроверяемом приведении типов
        demonstrateGenericArray(orders);
    }
    
    // Метод для демонстрации создания массива обобщённого типа
    @SuppressWarnings("unchecked")
    private static void demonstrateGenericArray(List<? extends OrderSystem.Order> orders) {
        // Вроде бы Java не позволяет создавать массивы обобщённых типов напрямую
        // Приходится использовать приведение типов и @SuppressWarnings
        // Создание массива Object и приведение его к типу Order[]
        OrderSystem.Order[] orderArray = new OrderSystem.Order[orders.size()];
        
        for (int i = 0; i < orders.size(); i++) {
            orderArray[i] = orders.get(i);
        }
        
        System.out.println("- Массив обобщённого типа создан (с @SuppressWarnings)");
        System.out.println("- Размер массива: " + orderArray.length);
    }
}
