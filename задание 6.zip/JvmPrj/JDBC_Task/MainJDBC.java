package JDBC_Task;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.List;

// Главный класс для демонстрации JDBC операций
public class MainJDBC {
    
    private static final String H2_URL = "jdbc:h2:mem:moviedb";
    private static final String H2_USER = "sa";
    private static final String H2_PASSWORD = "";
    
    public static void main(String[] args) {
        // Открытие одного соединения на всю программу
        try (Connection connection = DriverManager.getConnection(H2_URL, H2_USER, H2_PASSWORD)) {
            
            System.out.println("\n" + "=".repeat(80));
            System.out.println("РАБОТА С БАЗОЙ ДАННЫХ H2 ЧЕРЕЗ JDBC");
            System.out.println("=".repeat(80));
            
            // Создание DAO с открытым соединением
            MovieDAO dao = new MovieDAOImpl(connection);
            
            // Этап 1: Удаление и создание таблицы
            System.out.println("\nЭтап 1: Удаление и создание таблицы");
            System.out.println("-".repeat(80));
            dao.dropTable();
            dao.createTable();
            
            // Этап 2: Добавление четырех фильмов
            System.out.println("\nЭтап 2: Добавление фильмов");
            System.out.println("-".repeat(80));
            dao.addMovie(new Movie("Интерстеллар", "Научная фантастика", 2014));
            dao.addMovie(new Movie("Матрица", "Боевик", 1999));
            dao.addMovie(new Movie("Начало", "Триллер", 2010));
            dao.addMovie(new Movie("Тёмный рыцарь", "Боевик", 2008));
            
            // Этап 3: Просмотр всех фильмов
            System.out.println("\nЭтап 3: Все фильмы в базе");
            System.out.println("-".repeat(80));
            displayMovies(dao.getAllMovies());
            
            // Этап 4: Обновление названия фильма
            System.out.println("\nЭтап 4: Обновление названия фильма с ID = 2");
            System.out.println("-".repeat(80));
            dao.updateMovieTitle(2, "Матрица: Возрождение");
            
            // Этап 5: Просмотр после обновления
            System.out.println("\nЭтап 5: Фильмы после обновления");
            System.out.println("-".repeat(80));
            displayMovies(dao.getAllMovies());
            
            // Этап 6: Удаление фильма
            System.out.println("\nЭтап 6: Удаление фильма с ID = 3");
            System.out.println("-".repeat(80));
            dao.deleteMovie(3);
            
            // Этап 7: Просмотр после удаления
            System.out.println("\nЭтап 7: Фильмы после удаления");
            System.out.println("-".repeat(80));
            displayMovies(dao.getAllMovies());
            
            // Этап 8: Поиск по названию
            System.out.println("\nЭтап 8: Поиск по названию 'Матрица'");
            System.out.println("-".repeat(80));
            displayMovies(dao.findMoviesByTitle("Матрица"));
            
            // Этап 9: Поиск по жанру
            System.out.println("\nЭтап 9: Поиск по жанру 'Боевик'");
            System.out.println("-".repeat(80));
            displayMovies(dao.findMoviesByGenre("Боевик"));
            
            // Этап 10: Поиск по году
            System.out.println("\nЭтап 10: Поиск по году 2014");
            System.out.println("-".repeat(80));
            displayMovies(dao.findMoviesByYear(2014));
            
            // Этап 11: Поиск по ID
            System.out.println("\nЭтап 11: Поиск по ID = 1");
            System.out.println("-".repeat(80));
            Movie movie = dao.findMovieById(1);
            if (movie != null) {
                System.out.println(movie);
            } else {
                System.out.println("Фильм не найден");
            }
            
            System.out.println("\n" + "=".repeat(80));
            System.out.println("ПРОГРАММА ЗАВЕРШЕНА");
            System.out.println("=".repeat(80) + "\n");
            
        } catch (SQLException e) {
            System.err.println("Ошибка базы данных: " + e.getMessage());
            e.printStackTrace();
        }
    }
    
    private static void displayMovies(List<Movie> movies) {
        if (movies.isEmpty()) {
            System.out.println("Фильмы не найдены");
        } else {
            for (Movie movie : movies) {
                System.out.println(movie);
            }
        }
    }
}
