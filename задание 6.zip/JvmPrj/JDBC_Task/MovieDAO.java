package JDBC_Task;

import java.sql.SQLException;
import java.util.List;

// Интерфейс для операций с таблицей movies
public interface MovieDAO {
    
    // Создание таблицы
    void createTable() throws SQLException;
    
    // Удаление таблицы
    void dropTable() throws SQLException;
    
    // Добавление нового фильма
    void addMovie(Movie movie) throws SQLException;
    
    // Удаление фильма по ID
    void deleteMovie(int id) throws SQLException;
    
    // Обновление названия фильма
    void updateMovieTitle(int id, String newTitle) throws SQLException;
    
    // Поиск фильма по ID
    Movie findMovieById(int id) throws SQLException;
    
    // Поиск фильмов по названию
    List<Movie> findMoviesByTitle(String title) throws SQLException;
    
    // Поиск фильмов по жанру
    List<Movie> findMoviesByGenre(String genre) throws SQLException;
    
    // Поиск фильмов по году
    List<Movie> findMoviesByYear(int year) throws SQLException;
    
    // Получение всех фильмов
    List<Movie> getAllMovies() throws SQLException;
}