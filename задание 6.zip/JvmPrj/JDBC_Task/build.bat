@echo off
chcp 65001 > nul

echo.
echo ==============================================================
echo  РАБОТА С БАЗОЙ ДАННЫХ H2 (JDBC)
echo  Сборка и запуск (Фикс путей)
echo ==============================================================
echo.

cd /d "%~dp0"

:: Путь к джаве свой
set JAVA_HOME=D:\Work\UTILS\Java\jdk-21
set PATH=%JAVA_HOME%\bin;%PATH%

echo [1/2] Компиляция Java-классов...
javac -encoding UTF-8 ^
    Movie.java ^
    MovieDAO.java ^
    MovieDAOImpl.java ^
    MainJDBC.java

if errorlevel 1 goto error
echo Java-классы успешно скомпилированы
echo.

echo [2/2] Запуск программы...
echo.

cd ..

if exist "JDBC_Task\h2-2.1.214.jar" (
    java -cp .;JDBC_Task\h2-2.1.214.jar JDBC_Task.MainJDBC
) else if exist "h2-2.1.214.jar" (
    java -cp .;h2-2.1.214.jar JDBC_Task.MainJDBC
) else (
    echo Ошибка: Не найден файл h2-2.1.214.jar!
    goto error
)

if errorlevel 1 goto error
echo.
echo Программа завершена успешно!
exit /b 0

:error
echo.
echo Ошибка при сборке!
exit /b 1
