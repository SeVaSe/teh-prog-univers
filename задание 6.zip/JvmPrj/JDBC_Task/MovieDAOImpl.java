package JDBC_Task;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

// Реализация операций с базой данных для фильмов
public class MovieDAOImpl implements MovieDAO {
    private Connection connection;
    
    public MovieDAOImpl(Connection connection) {
        this.connection = connection;
    }
    
    @Override
    public void createTable() throws SQLException {
        String createTableSQL = "CREATE TABLE IF NOT EXISTS movies (" +
                "id INT AUTO_INCREMENT PRIMARY KEY, " +
                "title VARCHAR(255) NOT NULL, " +
                "genre VARCHAR(100) NOT NULL, " +
                "\"year\" INT NOT NULL)";
        
        try (PreparedStatement stmt = connection.prepareStatement(createTableSQL)) {
            stmt.executeUpdate();
            System.out.println("Таблица movies успешно создана");
        }
    }
    
    @Override
    public void dropTable() throws SQLException {
        String dropTableSQL = "DROP TABLE IF EXISTS movies";
        
        try (PreparedStatement stmt = connection.prepareStatement(dropTableSQL)) {
            stmt.executeUpdate();
            System.out.println("Таблица movies успешно удалена");
        }
    }
    
    // Добавление нового фильма
    @Override
    public void addMovie(Movie movie) throws SQLException {
        String insertSQL = "INSERT INTO movies (title, genre, \"year\") VALUES (?, ?, ?)";
        
        // Использование PreparedStatement для защиты от SQL-инъекций
        try (PreparedStatement stmt = connection.prepareStatement(insertSQL)) {
            // Установка параметров запроса
            stmt.setString(1, movie.getTitle());
            stmt.setString(2, movie.getGenre());
            stmt.setInt(3, movie.getYear());
            
            stmt.executeUpdate();
            System.out.println("Фильм добавлен: " + movie.getTitle());
        }
    }
    
    // Удаление фильма по ID
    @Override
    public void deleteMovie(int id) throws SQLException {
        String deleteSQL = "DELETE FROM movies WHERE id = ?";
        
        // Использование PreparedStatement для удаления по ID
        try (PreparedStatement stmt = connection.prepareStatement(deleteSQL)) {
            stmt.setInt(1, id);
            
            int rowsDeleted = stmt.executeUpdate();
            if (rowsDeleted > 0) {
                System.out.println("Фильм с ID " + id + " удалён");
            } else {
                System.out.println("Фильм с ID " + id + " не найден");
            }
        }
    }
    
    // Обновление названия фильма
    @Override
    public void updateMovieTitle(int id, String newTitle) throws SQLException {
        String updateSQL = "UPDATE movies SET title = ? WHERE id = ?";
        
        // Использование PreparedStatement для обновления
        try (PreparedStatement stmt = connection.prepareStatement(updateSQL)) {
            stmt.setString(1, newTitle);
            stmt.setInt(2, id);
            
            int rowsUpdated = stmt.executeUpdate();
            if (rowsUpdated > 0) {
                System.out.println("Фильм с ID " + id + " обновлён: " + newTitle);
            } else {
                System.out.println("Фильм с ID " + id + " не найден");
            }
        }
    }
    
    // Поиск фильма по ID
    @Override
    public Movie findMovieById(int id) throws SQLException {
        String selectSQL = "SELECT id, title, genre, \"year\" FROM movies WHERE id = ?";
        
        // Использование PreparedStatement для поиска
        try (PreparedStatement stmt = connection.prepareStatement(selectSQL)) {
            stmt.setInt(1, id);
            
            // Выполнение запроса и получение результата
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    return new Movie(
                            rs.getInt("id"),
                            rs.getString("title"),
                            rs.getString("genre"),
                            rs.getInt("year")
                    );
                }
            }
        }
        
        return null;
    }
    
    // Поиск фильмов по названию
    @Override
    public List<Movie> findMoviesByTitle(String title) throws SQLException {
        String selectSQL = "SELECT id, title, genre, \"year\" FROM movies WHERE LOWER(title) LIKE LOWER(?)";
        List<Movie> movies = new ArrayList<>();
        
        // Использование PreparedStatement с LIKE для частичного совпадения
        try (PreparedStatement stmt = connection.prepareStatement(selectSQL)) {
            stmt.setString(1, "%" + title + "%");
            
            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    movies.add(new Movie(
                            rs.getInt("id"),
                            rs.getString("title"),
                            rs.getString("genre"),
                            rs.getInt("year")
                    ));
                }
            }
        }
        
        return movies;
    }
    
    // Поиск фильмов по жанру
    @Override
    public List<Movie> findMoviesByGenre(String genre) throws SQLException {
        String selectSQL = "SELECT id, title, genre, \"year\" FROM movies WHERE LOWER(genre) = LOWER(?)";
        List<Movie> movies = new ArrayList<>();
        
        // Использование PreparedStatement для поиска по жанру
        try (PreparedStatement stmt = connection.prepareStatement(selectSQL)) {
            stmt.setString(1, genre);
            
            // Выполнение запроса и получение результатов
            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    movies.add(new Movie(
                            rs.getInt("id"),
                            rs.getString("title"),
                            rs.getString("genre"),
                            rs.getInt("year")
                    ));
                }
            }
        }
        
        return movies;
    }
    
    // Поиск фильмов по году
    @Override
    public List<Movie> findMoviesByYear(int year) throws SQLException {
        String selectSQL = "SELECT id, title, genre, \"year\" FROM movies WHERE \"year\" = ?";
        List<Movie> movies = new ArrayList<>();
        
        try (PreparedStatement stmt = connection.prepareStatement(selectSQL)) {
            stmt.setInt(1, year);
            
            // Выполнение запроса и получение результатов
            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    movies.add(new Movie(
                            rs.getInt("id"),
                            rs.getString("title"),
                            rs.getString("genre"),
                            rs.getInt("year")
                    ));
                }
            }
        }
        
        return movies;
    }
    
    // Получение всех фильмов
    @Override
    public List<Movie> getAllMovies() throws SQLException {
        String selectSQL = "SELECT id, title, genre, \"year\" FROM movies ORDER BY id";
        List<Movie> movies = new ArrayList<>();
        
        // Использование PreparedStatement для получения всех записей
        try (PreparedStatement stmt = connection.prepareStatement(selectSQL)) {
            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    movies.add(new Movie(
                            rs.getInt("id"),
                            rs.getString("title"),
                            rs.getString("genre"),
                            rs.getInt("year")
                    ));
                }
            }
        }
        
        return movies;
    }
}
