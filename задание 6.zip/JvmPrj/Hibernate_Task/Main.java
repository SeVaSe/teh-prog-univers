package com.example;

import com.example.entity.Movie;
import com.example.dao.MovieDao;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

public class Main {
    public static void main(String[] args) {
        try (SessionFactory sessionFactory = new Configuration()
                .configure("hibernate.cfg.xml")
                .buildSessionFactory()) {
            MovieDao movieDao = new MovieDao(sessionFactory);

            System.out.println("=== Сохранение фильмов ===");
            Movie movie1 = new Movie("Inception", "Sci-Fi", 2010, 8.8);
            Movie movie2 = new Movie("The Dark Knight", "Action", 2008, 9.0);
            Movie movie3 = new Movie("Interstellar", "Sci-Fi", 2014, 8.6);
            Movie movie4 = new Movie("Titanic", "Drama", 1997, 7.8);

            movieDao.save(movie1);
            movieDao.save(movie2);
            movieDao.save(movie3);
            movieDao.save(movie4);

            System.out.println("\n=== Все фильмы ===");
            movieDao.findAll().forEach(System.out::println);

            System.out.println("\n=== Обновление фильма (ID=1) ===");
            movieDao.updateByHQL(1, "Inception Updated", 8.9);
            System.out.println("Фильм обновлен");
            movieDao.findAll().forEach(System.out::println);

            System.out.println("\n=== Поиск по названию 'Dark' ===");
            movieDao.findByTitle("Dark").forEach(System.out::println);

            System.out.println("\n=== Поиск по жанру 'Sci-Fi' ===");
            movieDao.findByGenre("Sci-Fi").forEach(System.out::println);

            System.out.println("\n=== Поиск по году 2014 ===");
            movieDao.findByYear(2014).forEach(System.out::println);

            System.out.println("\n=== Удаление фильма (ID=4) ===");
            movieDao.deleteById(4);
            System.out.println("Фильм удален");
            movieDao.findAll().forEach(System.out::println);
        }

        System.out.println("\n=== Программа завершена ===");
    }
}
