package com.example.entity;

import jakarta.persistence.*;

@Entity
@Table(name = "movies")
public class Movie {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;
    
    @Column(name = "title", nullable = false)
    private String title;
    
    @Column(name = "genre")
    private String genre;
    
    @Column(name = "release_year")
    private Integer year;
    
    @Column(name = "rating")
    private Double rating;
    
    public Movie() {}
    
    public Movie(String title, String genre, Integer year, Double rating) {
        this.title = title;
        this.genre = genre;
        this.year = year;
        this.rating = rating;
    }
    
    public Integer getId() { return id; }
    public void setId(Integer id) { this.id = id; }
    public String getTitle() { return title; }
    public void setTitle(String title) { this.title = title; }
    public String getGenre() { return genre; }
    public void setGenre(String genre) { this.genre = genre; }
    public Integer getYear() { return year; }
    public void setYear(Integer year) { this.year = year; }
    public Double getRating() { return rating; }
    public void setRating(Double rating) { this.rating = rating; }
    
    @Override
    public String toString() {
        return "Movie{" +
                "id=" + id +
                ", title='" + title + '\'' +
                ", genre='" + genre + '\'' +
                ", year=" + year +
                ", rating=" + rating +
                '}';
    }
}