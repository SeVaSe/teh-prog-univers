package com.example.dao;

import com.example.entity.Movie;
import jakarta.persistence.criteria.CriteriaBuilder;
import jakarta.persistence.criteria.CriteriaQuery;
import jakarta.persistence.criteria.Root;
import org.hibernate.Session;
import org.hibernate.SessionFactory;

import java.util.List;

public class MovieDao {
    private final SessionFactory sessionFactory;

    public MovieDao(SessionFactory sessionFactory) {
        this.sessionFactory = sessionFactory;
    }

    // Сохранение фильма
    public void save(Movie movie) {
        try (Session session = sessionFactory.openSession()) {
            session.beginTransaction();
            session.persist(movie);
            session.getTransaction().commit();
        }
    }

    // Обновление фильма по HQL
    public void updateByHQL(Integer id, String newTitle, Double newRating) {
        try (Session session = sessionFactory.openSession()) {
            session.beginTransaction();
            session.createMutationQuery(
                            "UPDATE Movie SET title = :title, rating = :rating WHERE id = :id")
                    .setParameter("title", newTitle)
                    .setParameter("rating", newRating)
                    .setParameter("id", id)
                    .executeUpdate();
            session.getTransaction().commit();
        }
    }

    // Удаление по ID
    public void deleteById(Integer id) {
        try (Session session = sessionFactory.openSession()) {
            session.beginTransaction();
            Movie movie = session.get(Movie.class, id);
            if (movie != null) {
                session.remove(movie);
            }
            session.getTransaction().commit();
        }
    }

    // Поиск по названию через Criteria API
    public List<Movie> findByTitle(String title) {
        try (Session session = sessionFactory.openSession()) {
            CriteriaBuilder builder = session.getCriteriaBuilder();
            CriteriaQuery<Movie> criteria = builder.createQuery(Movie.class);
            Root<Movie> movie = criteria.from(Movie.class);
            criteria.select(movie).where(builder.like(movie.get("title"), "%" + title + "%"));
            return session.createQuery(criteria).getResultList();
        }
    }

    // Поиск по жанру через Criteria API
    public List<Movie> findByGenre(String genre) {
        try (Session session = sessionFactory.openSession()) {
            CriteriaBuilder builder = session.getCriteriaBuilder();
            CriteriaQuery<Movie> criteria = builder.createQuery(Movie.class);
            Root<Movie> movie = criteria.from(Movie.class);
            criteria.select(movie).where(builder.equal(movie.get("genre"), genre));
            return session.createQuery(criteria).getResultList();
        }
    }

    // Поиск по году через Criteria API
    public List<Movie> findByYear(Integer year) {
        try (Session session = sessionFactory.openSession()) {
            CriteriaBuilder builder = session.getCriteriaBuilder();
            CriteriaQuery<Movie> criteria = builder.createQuery(Movie.class);
            Root<Movie> movie = criteria.from(Movie.class);
            criteria.select(movie).where(builder.equal(movie.get("year"), year));
            return session.createQuery(criteria).getResultList();
        }
    }

    // Получить все фильмы
    public List<Movie> findAll() {
        try (Session session = sessionFactory.openSession()) {
            return session.createQuery("FROM Movie", Movie.class).getResultList();
        }
    }
}
