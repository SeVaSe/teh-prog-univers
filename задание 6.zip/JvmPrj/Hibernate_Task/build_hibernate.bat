@echo off
chcp 65001 > nul
setlocal EnableExtensions EnableDelayedExpansion

echo.
echo ==============================================================
echo  РАБОТА С БАЗОЙ ДАННЫХ H2 (HIBERNATE)
echo  Сборка и запуск
echo ==============================================================
echo.

cd /d "%~dp0"

set JAVA_HOME=D:\Work\UTILS\Java\jdk-21
set PATH=%JAVA_HOME%\bin;%PATH%

echo [1/5] Проверка наличия файлов...
if not exist "Movie.java" (
    echo Ошибка: Movie.java не найден!
    exit /b 1
)
if not exist "MovieDao.java" (
    echo Ошибка: MovieDao.java не найден!
    exit /b 1
)
if not exist "Main.java" (
    echo Ошибка: Main.java не найден!
    exit /b 1
)
if not exist "hibernate.cfg.xml" (
    echo Ошибка: hibernate.cfg.xml не найден!
    exit /b 1
)
where curl.exe > nul 2>&1
if errorlevel 1 (
    echo Ошибка: curl.exe не найден. Установите curl и повторите запуск.
    exit /b 1
)
echo Все файлы найдены
echo.

echo Скачивание библиотек во временную папку...
set "DEPENDENCY_DIR=%TEMP%\Hibernate_Task_lib_%RANDOM%_%RANDOM%"
mkdir "%DEPENDENCY_DIR%"
if errorlevel 1 (
    echo Ошибка при создании временной папки для библиотек!
    goto cleanup_failure
)

call :download_dependency "org/jboss/logging/jboss-logging/3.5.0.Final/jboss-logging-3.5.0.Final.jar"
if errorlevel 1 goto dependency_failure
call :download_dependency "org/hibernate/common/hibernate-commons-annotations/6.0.6.Final/hibernate-commons-annotations-6.0.6.Final.jar"
if errorlevel 1 goto dependency_failure
call :download_dependency "io/smallrye/jandex/3.1.2/jandex-3.1.2.jar"
if errorlevel 1 goto dependency_failure
call :download_dependency "com/fasterxml/classmate/1.5.1/classmate-1.5.1.jar"
if errorlevel 1 goto dependency_failure
call :download_dependency "net/bytebuddy/byte-buddy/1.14.7/byte-buddy-1.14.7.jar"
if errorlevel 1 goto dependency_failure
call :download_dependency "jakarta/xml/bind/jakarta.xml.bind-api/4.0.0/jakarta.xml.bind-api-4.0.0.jar"
if errorlevel 1 goto dependency_failure
call :download_dependency "org/glassfish/jaxb/jaxb-runtime/4.0.2/jaxb-runtime-4.0.2.jar"
if errorlevel 1 goto dependency_failure
call :download_dependency "jakarta/inject/jakarta.inject-api/2.0.1/jakarta.inject-api-2.0.1.jar"
if errorlevel 1 goto dependency_failure
call :download_dependency "org/antlr/antlr4-runtime/4.13.0/antlr4-runtime-4.13.0.jar"
if errorlevel 1 goto dependency_failure
call :download_dependency "org/glassfish/jaxb/jaxb-core/4.0.2/jaxb-core-4.0.2.jar"
if errorlevel 1 goto dependency_failure
call :download_dependency "org/glassfish/jaxb/txw2/4.0.2/txw2-4.0.2.jar"
if errorlevel 1 goto dependency_failure
call :download_dependency "com/sun/istack/istack-commons-runtime/4.1.1/istack-commons-runtime-4.1.1.jar"
if errorlevel 1 goto dependency_failure
call :download_dependency "jakarta/activation/jakarta.activation-api/2.1.1/jakarta.activation-api-2.1.1.jar"
if errorlevel 1 goto dependency_failure
call :download_dependency "org/eclipse/angus/angus-activation/2.0.0/angus-activation-2.0.0.jar"
if errorlevel 1 goto dependency_failure
call :download_dependency "com/h2database/h2/2.1.214/h2-2.1.214.jar"
if errorlevel 1 goto dependency_failure
call :download_dependency "org/hibernate/orm/hibernate-core/6.4.0.Final/hibernate-core-6.4.0.Final.jar"
if errorlevel 1 goto dependency_failure
call :download_dependency "jakarta/persistence/jakarta.persistence-api/3.1.0/jakarta.persistence-api-3.1.0.jar"
if errorlevel 1 goto dependency_failure
call :download_dependency "jakarta/transaction/jakarta.transaction-api/2.0.1/jakarta.transaction-api-2.0.1.jar"
if errorlevel 1 goto dependency_failure
call :download_dependency "org/slf4j/slf4j-api/2.0.9/slf4j-api-2.0.9.jar"
if errorlevel 1 goto dependency_failure
call :download_dependency "org/slf4j/slf4j-simple/2.0.9/slf4j-simple-2.0.9.jar"
if errorlevel 1 goto dependency_failure
goto dependencies_ready

:dependency_failure
echo Ошибка при скачивании библиотек. Проверьте подключение к интернету.
goto cleanup_failure

:dependencies_ready
echo Все библиотеки загружены
echo.

echo [2/5] Очистка старых скомпилированных файлов...
if exist "com" (
    rmdir /s /q com
    echo Старые файлы удалены
) else (
    echo Нет старых файлов для удаления
)
echo.

echo [3/5] Создание структуры папок...
if not exist "com\example\entity" mkdir com\example\entity
if not exist "com\example\dao" mkdir com\example\dao
echo Структура папок создана
echo.

echo [4/5] Компиляция Java-классов...

REM Построение classpath со всеми загруженными библиотеками
set CLASSPATH=.
for %%f in ("%DEPENDENCY_DIR%\*.jar") do (
    set CLASSPATH=!CLASSPATH!;%%f
)

echo Используемые библиотеки:
echo %CLASSPATH%
echo.

REM Компиляция Movie.java в правильную папку
echo Компиляция Movie.java...
javac -encoding UTF-8 -cp "%CLASSPATH%" -d . Movie.java
if errorlevel 1 (
    echo Ошибка при компиляции Movie.java!
    goto cleanup_failure
)

REM Компиляция MovieDao.java в правильную папку
echo Компиляция MovieDao.java...
javac -encoding UTF-8 -cp "%CLASSPATH%" -d . MovieDao.java
if errorlevel 1 (
    echo Ошибка при компиляции MovieDao.java!
    goto cleanup_failure
)

REM Компиляция Main.java
echo Компиляция Main.java...
javac -encoding UTF-8 -cp "%CLASSPATH%" -d . Main.java
if errorlevel 1 (
    echo Ошибка при компиляции Main.java!
    goto cleanup_failure
)

echo Java-классы успешно скомпилированы
echo.

echo [5/5] Запуск программы...
echo.
echo ==============================================================
echo.

REM Запуск с правильным classpath
java -cp ".;%CLASSPATH%" com.example.Main

if errorlevel 1 (
    echo Ошибка при запуске!
    goto cleanup_failure
)

goto cleanup_success

:cleanup_failure
if defined DEPENDENCY_DIR if exist "%DEPENDENCY_DIR%" rmdir /s /q "%DEPENDENCY_DIR%"
endlocal
exit /b 1

:cleanup_success
if defined DEPENDENCY_DIR if exist "%DEPENDENCY_DIR%" rmdir /s /q "%DEPENDENCY_DIR%"
endlocal
echo.
echo ==============================================================
echo Программа завершена успешно!
echo ==============================================================
pause
exit /b 0

:download_dependency
for %%f in ("%~1") do set "JAR_NAME=%%~nxf"
curl.exe --fail --location --silent --show-error --retry 2 "https://repo.maven.apache.org/maven2/%~1" --output "%DEPENDENCY_DIR%\%JAR_NAME%"
if errorlevel 1 exit /b 1
exit /b 0