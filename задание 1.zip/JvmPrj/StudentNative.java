public class StudentNative {
    static {
        System.loadLibrary("StudentNative");
    }
    
    public native void printName();
    public native void printPatronymic();
    public native void printSurname();
}