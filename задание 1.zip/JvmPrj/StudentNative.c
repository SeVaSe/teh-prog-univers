#include <jni.h>
#include <stdio.h>
#include "StudentNative.h"

JNIEXPORT void JNICALL Java_StudentNative_printName
  (JNIEnv *env, jobject obj) {
    printf("Имя: Иван\n");
    fflush(stdout);
}

JNIEXPORT void JNICALL Java_StudentNative_printPatronymic
  (JNIEnv *env, jobject obj) {
    printf("Отчество: Иванович\n");
    fflush(stdout);
}

JNIEXPORT void JNICALL Java_StudentNative_printSurname
  (JNIEnv *env, jobject obj) {
    printf("Фамилия: Иванов\n");
    fflush(stdout);
}