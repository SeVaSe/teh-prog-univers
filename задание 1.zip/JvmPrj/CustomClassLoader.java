import java.io.*;
import java.nio.file.*;

public class CustomClassLoader extends ClassLoader {
    private String classPath;
    
    public CustomClassLoader(String classPath, ClassLoader parent) {
        super(parent);
        this.classPath = classPath;
    }
    
    @Override
    protected Class<?> findClass(String name) throws ClassNotFoundException {
        System.out.println("[CustomClassLoader] Загрузка класса: " + name);
        
        String filename = name.replace('.', '/') + ".class";
        
        try {
            byte[] classData = Files.readAllBytes(
                Paths.get(classPath, filename)
            );
            
            Class<?> loadedClass = defineClass(name, classData, 0, classData.length);
            
            System.out.println("[CustomClassLoader] Класс загружен: " + name);
            return loadedClass;
            
        } catch (IOException e) {
            throw new ClassNotFoundException("Не найден класс: " + name, e);
        }
    }
}
