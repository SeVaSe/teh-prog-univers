import java.lang.reflect.*;

public class Main {
    public static void main(String[] args) {
        try {
            System.out.println("Демонстрация JNI и Custom ClassLoader\n");
            
            String classPath = System.getProperty("user.dir");
            System.out.println("Путь к классам: " + classPath);
            
            CustomClassLoader customLoader = new CustomClassLoader(
                classPath, 
                ClassLoader.getSystemClassLoader()
            );
            
            System.out.println("\nЗагрузка класса StudentNative");
            
            Class<?> studentClass = customLoader.loadClass("StudentNative");
            
            System.out.println("\nСоздание экземпляра ");
            
            Object studentInstance = studentClass.getDeclaredConstructor().newInstance();
            System.out.println("Экземпляр создан: " + studentInstance);
            
            System.out.println("\n Вызов native-методов \n");
            
            Method printName = studentClass.getDeclaredMethod("printName");
            Method printPatronymic = studentClass.getDeclaredMethod("printPatronymic");
            Method printSurname = studentClass.getDeclaredMethod("printSurname");
            
            System.out.println("Вызов printName():");
            printName.invoke(studentInstance);
            
            System.out.println("\nВызов printPatronymic():");
            printPatronymic.invoke(studentInstance);
            
            System.out.println("\nВызов printSurname():");
            printSurname.invoke(studentInstance);
            
            System.out.println("\nУспешное завершение программы");
            
        } catch (ClassNotFoundException e) {
            System.err.println("Ошибка: класс не найден");
            e.printStackTrace();
        } catch (Exception e) {
            System.err.println("Ошибка при выполнении: " + e.getMessage());
            e.printStackTrace();
        }
    }
}
