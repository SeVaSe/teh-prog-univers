@echo off
chcp 65001 > nul

echo === Сборка ===
echo.

REM Установка пути к JDK
set JAVA_HOME=D:\Work\UTILS\Java\jdk-21
if not exist "%JAVA_HOME%" (
    echo Ошибка: JDK не найден в %JAVA_HOME%
    exit /b 1
)

echo [1/4] Компиляция Java-классов...
javac -encoding UTF-8 StudentNative.java CustomClassLoader.java Main.java
if errorlevel 1 goto error
echo Java-классы скомпилированы

echo.
echo [2/4] Генерация заголовочного файла...
javac -h . StudentNative.java
if errorlevel 1 goto error
echo Заголовочный файл создан

echo.
echo [3/4] Компиляция C-кода в DLL...
set "ORIGINAL_DIR=%CD%"

:: здесь поменять на другое расположение вашего Build-дера, который у вас стоит на компе
cd /d "D:\Work\IDE\VS26\Community\VC\Auxiliary\Build"
call vcvars64.bat > nul
cd /d "%ORIGINAL_DIR%"

cl /I"%JAVA_HOME%\include" /I"%JAVA_HOME%\include\win32" ^
   /LD StudentNative.c /Fe:StudentNative.dll
if errorlevel 1 goto error
echo Нативная библиотека создана

echo.
echo [4/4] Запуск программы...
java --enable-native-access=ALL-UNNAMED -Djava.library.path=. Main
if errorlevel 1 goto error

echo.
echo Сборка и запуск завершены успешно!
exit /b 0

:error
echo.
echo Ошибка при сборке!
exit /b 1
