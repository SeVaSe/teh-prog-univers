СТРУКТУРА:
- StudentNative.java: класс с тремя native-методами
- StudentNative.c: реализация native-методов на C
- CustomClassLoader.java: собственный загрузчик классов
- Main.java: главная программа

КОМПИЛЯЦИЯ И ЗАПУСК:
Windows:
  build.bat

ВИДЕО ДЕМОНСТРАЦИЯ:
после перехода по ссылке, нажать "View raw", видео скачается и можно просмотреть
https://github.com/SeVaSe/teh-prog-univers/blob/main/%D0%B7%D0%B0%D0%B4%D0%B0%D0%BD%D0%B8%D0%B5%201.mkv

ТРЕБОВАНИЯ:
- Java JDK 11+
- Visual Studio (Windows)
