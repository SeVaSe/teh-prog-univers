@echo off
chcp 65001 > nul
setlocal EnableExtensions

cd /d "%~dp0"
title Documented Java Business Module

echo.
echo ==============================================================
echo  JAVA BUSINESS MODULE — JUNIT 5 AND JAVADOC
echo ==============================================================
echo.

where java.exe > nul 2>&1
if errorlevel 1 (
    echo Ошибка: Java не найдена. Установите JDK 21 или новее.
    goto failure
)
if defined JAVA_HOME if not exist "%JAVA_HOME%\bin\java.exe" set "JAVA_HOME="
if not defined JAVA_HOME (
    for /f "delims=" %%J in ('powershell.exe -NoProfile -Command "$java=(Get-Command java.exe).Source; (Resolve-Path (Join-Path (Split-Path $java -Parent) '..')).Path"') do set "JAVA_HOME=%%J"
)
if not exist "%JAVA_HOME%\bin\javac.exe" (
    echo Ошибка: требуется JDK с javac.exe, найдено: %JAVA_HOME%
    goto failure
)
set "PATH=%JAVA_HOME%\bin;%PATH%"
where curl.exe > nul 2>&1
if errorlevel 1 (
    echo Ошибка: curl.exe не найден. Для первой сборки нужен интернет.
    goto failure
)

set "MAVEN_VERSION=3.9.9"
set "MAVEN_HOME=%USERPROFILE%\.m2\wrapper\dists\apache-maven-%MAVEN_VERSION%"
set "MAVEN_CMD=%MAVEN_HOME%\bin\mvn.cmd"
if exist "%MAVEN_CMD%" goto maven_ready

echo Загрузка Apache Maven %MAVEN_VERSION%...
set "MAVEN_CACHE=%USERPROFILE%\.m2\wrapper\dists"
set "MAVEN_ARCHIVE=%TEMP%\apache-maven-%MAVEN_VERSION%-%RANDOM%.zip"
if not exist "%MAVEN_CACHE%" mkdir "%MAVEN_CACHE%"
curl.exe --fail --location --silent --show-error --retry 2 "https://archive.apache.org/dist/maven/maven-3/%MAVEN_VERSION%/binaries/apache-maven-%MAVEN_VERSION%-bin.zip" --output "%MAVEN_ARCHIVE%"
if errorlevel 1 (
    echo Ошибка загрузки Apache Maven.
    if exist "%MAVEN_ARCHIVE%" del /q "%MAVEN_ARCHIVE%"
    goto failure
)
powershell.exe -NoProfile -ExecutionPolicy Bypass -Command "Expand-Archive -LiteralPath '%MAVEN_ARCHIVE%' -DestinationPath '%MAVEN_CACHE%' -Force"
if errorlevel 1 (
    echo Ошибка распаковки Apache Maven.
    if exist "%MAVEN_ARCHIVE%" del /q "%MAVEN_ARCHIVE%"
    goto failure
)
del /q "%MAVEN_ARCHIVE%"
if not exist "%MAVEN_CMD%" (
    echo Ошибка: mvn.cmd не найден после распаковки Maven.
    goto failure
)

:maven_ready
echo Запуск JUnit 5 suite и создание Javadoc...
call "%MAVEN_CMD%" -B test javadoc:javadoc
if errorlevel 1 goto failure
echo.
echo Все тесты выполнены. Javadoc создан в target\reports\apidocs.
goto success

:failure
echo.
echo Сборка или проверка завершилась с ошибкой.
pause
endlocal
exit /b 1

:success
echo.
echo Готово.
pause
endlocal
exit /b 0
