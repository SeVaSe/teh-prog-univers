# Классы бизнес-логики
- `Customer` — проверяет и нормализует имя и email; email определяет идентичность покупателя.
- `Product` — хранит SKU, цену и доступный остаток; синхронизирует резервирование и возврат остатков.
- `Order` — управляет товарными позициями, итоговой суммой, резервированием склада и состояниями `DRAFT`, `PLACED`, `CANCELLED`.

# Тестирование

Тесты используют JUnit 5:

- стандартные unit-тесты для валидации, расчёта цены и переходов состояния;
- параметризованные тесты с `@ValueSource` и `@ParameterizedTest`;
- повторяемый тест с `@RepeatedTest`;
- динамические тесты с `@TestFactory` и `DynamicTest`;
- общий suite `BusinessModuleSuiteTest` с `@Suite` и `@SelectClasses`.

Запустите `build_module.bat` или выполните `mvn test javadoc:javadoc`. Скрипт автоматически скачает Apache Maven при необходимости. Требуется JDK 21+ и интернет при первой сборке. Отчёты JUnit появятся в `target\surefire-reports`, Javadoc — в `target\reports\apidocs`.
