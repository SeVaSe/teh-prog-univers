package app.business;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Objects;

/**
 * Представляет заказ покупателя и управляет резервированием товаров.
 *
 * <p>При добавлении товара его остаток резервируется сразу, а текущая цена
 * за единицу фиксируется. Оформление завершает заказ, а отмена черновика
 * возвращает весь зарезервированный им товар.</p>
 *
 */
public final class Order {
    /**
     * Текущее состояние заказа.
     *
     */
    public enum Status {
        /** Заказ можно изменять. */
        DRAFT,
        /** Заказ оформлен. */
        PLACED,
        /** Черновик отменён, зарезервированный товар возвращён на склад. */
        CANCELLED
    }

    /**
     * Неизменяемая позиция заказа с товаром и зафиксированной на момент добавления ценой.
     *
     * @param product товар в заказе
     * @param quantity положительное количество единиц товара
     * @param unitPrice цена за единицу, зафиксированная при добавлении позиции
     */
    public record LineItem(Product product, int quantity, BigDecimal unitPrice) {
        /**
         * Создаёт и проверяет позицию заказа.
         *
         * @param product товар в заказе
         * @param quantity положительное количество единиц товара
         * @param unitPrice цена за единицу, зафиксированная при добавлении позиции
         * @throws NullPointerException если обязательное значение равно {@code null}
         * @throws IllegalArgumentException если количество или цена не являются положительными
         */
        public LineItem {
            Objects.requireNonNull(product, "Product must not be null.");
            Objects.requireNonNull(unitPrice, "Unit price must not be null.");
            if (quantity <= 0) {
                throw new IllegalArgumentException("Line item quantity must be greater than zero.");
            }
            if (unitPrice.signum() <= 0) {
                throw new IllegalArgumentException("Line item unit price must be greater than zero.");
            }
        }

        /**
         * Вычисляет полную стоимость позиции заказа.
         *
         * @return цена за единицу, умноженная на количество
         */
        public BigDecimal getLineTotal() {
            return unitPrice.multiply(BigDecimal.valueOf(quantity));
        }
    }

    private final String orderNumber;
    private final Customer customer;
    private final List<LineItem> items = new ArrayList<>();
    private Status status = Status.DRAFT;

    /**
     * Создаёт пустой черновик заказа для покупателя.
     *
     * @param orderNumber непустой бизнес-идентификатор заказа
     * @param customer покупатель, которому принадлежит заказ
     * @throws NullPointerException если номер заказа или покупатель равен {@code null}
     * @throws IllegalArgumentException если номер заказа пуст
     */
    public Order(String orderNumber, Customer customer) {
        Objects.requireNonNull(orderNumber, "Order number must not be null.");
        this.customer = Objects.requireNonNull(customer, "Order customer must not be null.");
        if (orderNumber.isBlank()) {
            throw new IllegalArgumentException("Order number must not be blank.");
        }
        this.orderNumber = orderNumber.trim();
    }

    /**
     * Возвращает бизнес-идентификатор заказа.
     *
     * @return номер заказа
     */
    public String getOrderNumber() {
        return orderNumber;
    }

    /**
     * Возвращает покупателя, которому принадлежит заказ.
     *
     * @return покупатель, оформивший заказ
     */
    public Customer getCustomer() {
        return customer;
    }

    /**
     * Возвращает текущее состояние заказа.
     *
     * @return состояние заказа
     */
    public synchronized Status getStatus() {
        return status;
    }

    /**
     * Возвращает неизменяемый снимок позиций заказа.
     *
     * @return список позиций, который нельзя изменить
     */
    public synchronized List<LineItem> getItems() {
        return Collections.unmodifiableList(new ArrayList<>(items));
    }

    /**
     * Добавляет товар в черновик заказа и резервирует его остаток.
     *
     * <p>Если товар уже добавлен, указанное количество суммируется с имеющимся.
     * Остаток изменяется только после проверки итогового количества.</p>
     *
     * @param product добавляемый товар
     * @param quantity положительное количество добавляемых единиц
     * @throws NullPointerException если товар равен {@code null}
     * @throws IllegalArgumentException если заказ не является черновиком, количество некорректно
     *                                  или остатка товара недостаточно
     */
    public synchronized void addProduct(Product product, int quantity) {
        ensureDraft();
        Objects.requireNonNull(product, "Product must not be null.");
        if (quantity <= 0) {
            throw new IllegalArgumentException("Order quantity must be greater than zero.");
        }

        int index = findItemIndex(product);
        int combinedQuantity = quantity;
        if (index >= 0) {
            combinedQuantity = Math.addExact(items.get(index).quantity(), quantity);
        }
        product.reserve(quantity);
        if (index >= 0) {
            items.set(index, new LineItem(product, combinedQuantity, items.get(index).unitPrice()));
        } else {
            items.add(new LineItem(product, quantity, product.getUnitPrice()));
        }
    }

    /**
     * Вычисляет сумму заказа по ценам, зафиксированным при добавлении товаров.
     *
     * @return сумма стоимостей всех позиций; для пустого черновика — ноль
     */
    public synchronized BigDecimal getTotal() {
        return items.stream()
                .map(LineItem::getLineTotal)
                .reduce(BigDecimal.ZERO, BigDecimal::add);
    }

    /**
     * Оформляет непустой черновик заказа.
     *
     * @throws IllegalStateException если заказ не является черновиком или не содержит позиций
     */
    public synchronized void place() {
        ensureDraft();
        if (items.isEmpty()) {
            throw new IllegalStateException("An empty order cannot be placed.");
        }
        status = Status.PLACED;
    }

    /**
     * Отменяет черновик заказа и возвращает на склад всё зарезервированное количество товаров.
     *
     * @throws IllegalStateException если заказ не является черновиком
     */
    public synchronized void cancel() {
        ensureDraft();
        for (LineItem item : items) {
            item.product().release(item.quantity());
        }
        items.clear();
        status = Status.CANCELLED;
    }

    private int findItemIndex(Product product) {
        for (int index = 0; index < items.size(); index++) {
            if (items.get(index).product().getSku().equals(product.getSku())) {
                if (items.get(index).product() != product) {
                    throw new IllegalArgumentException(
                            "A different product instance already uses SKU %s.".formatted(product.getSku()));
                }
                return index;
            }
        }
        return -1;
    }

    private void ensureDraft() {
        if (status != Status.DRAFT) {
            throw new IllegalStateException("Order %s is %s and can no longer be changed."
                    .formatted(orderNumber, status));
        }
    }
}
