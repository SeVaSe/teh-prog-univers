package app.business;

import java.util.Objects;
import java.util.regex.Pattern;

/**
 * Представляет покупателя, который может оформлять заказы в бизнес-модуле.
 *
 * <p>Имя покупателя обрезается при сохранении, а адрес электронной почты
 * проверяется перед созданием объекта.</p>
 *
 */
public final class Customer {
    private static final Pattern EMAIL_PATTERN =
            Pattern.compile("^[^\\s@]+@[^\\s@]+\\.[^\\s@]+$");

    private final String name;
    private final String email;

    /**
     * Создаёт покупателя с отображаемым именем и адресом электронной почты.
     *
     * @param name отображаемое имя покупателя; от 2 до 80 символов
     * @param email адрес электронной почты покупателя
     * @throws NullPointerException если {@code name} или {@code email} равен {@code null}
     * @throws IllegalArgumentException если имя или адрес электронной почты некорректны
     */
    public Customer(String name, String email) {
        Objects.requireNonNull(name, "Customer name must not be null.");
        Objects.requireNonNull(email, "Customer email must not be null.");
        String normalizedName = name.trim();
        String normalizedEmail = email.trim();
        if (normalizedName.length() < 2 || normalizedName.length() > 80) {
            throw new IllegalArgumentException("Customer name must contain 2 to 80 characters.");
        }
        if (!EMAIL_PATTERN.matcher(normalizedEmail).matches()) {
            throw new IllegalArgumentException("Customer email address is invalid.");
        }
        this.name = normalizedName;
        this.email = normalizedEmail.toLowerCase(java.util.Locale.ROOT);
    }

    /**
     * Возвращает отображаемое имя покупателя.
     *
     * @return имя покупателя без пробелов по краям
     */
    public String getName() {
        return name;
    }

    /**
     * Возвращает нормализованный адрес электронной почты покупателя.
     *
     * @return адрес электронной почты в нижнем регистре
     */
    public String getEmail() {
        return email;
    }

    /**
     * Сравнивает покупателей по нормализованному адресу электронной почты.
     *
     * @param other объект для сравнения с этим покупателем
     * @return {@code true}, если другой объект — покупатель с таким же адресом электронной почты
     */
    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (!(other instanceof Customer customer)) {
            return false;
        }
        return email.equals(customer.email);
    }

    /**
     * Возвращает хеш-код, согласованный с {@link #equals(Object)}.
     *
     * @return хеш-код, вычисленный на основе нормализованного адреса электронной почты
     */
    @Override
    public int hashCode() {
        return email.hashCode();
    }

    /**
     * Возвращает представление покупателя, не раскрывающее учётные данные.
     *
     * @return имя покупателя и адрес электронной почты
     */
    @Override
    public String toString() {
        return "Customer{name='%s', email='%s'}".formatted(name, email);
    }
}
