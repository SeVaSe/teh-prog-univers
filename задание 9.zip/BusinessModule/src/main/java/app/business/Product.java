package app.business;

import java.math.BigDecimal;
import java.util.Locale;
import java.util.Objects;

/**
 * Представляет товар с заданной ценой и ограниченным резервируемым запасом.
 *
 * <p>Операции с запасом синхронизированы: два заказа не смогут одновременно
 * зарезервировать одну и ту же доступную единицу товара.</p>
 *
 */
public final class Product {
    private final String sku;
    private final String name;
    private final BigDecimal unitPrice;
    private int availableStock;

    /**
     * Создаёт товар с артикулом, названием, ценой за единицу и количеством на складе.
     *
     * @param sku артикул товара; не должен быть пустым
     * @param name отображаемое название товара; не должно быть пустым
     * @param unitPrice цена товара; должна быть больше нуля
     * @param availableStock начальное количество товара; не должно быть отрицательным
     * @throws NullPointerException если обязательная строка или цена равна {@code null}
     * @throws IllegalArgumentException если какое-либо значение товара некорректно
     */
    public Product(String sku, String name, BigDecimal unitPrice, int availableStock) {
        Objects.requireNonNull(sku, "Product SKU must not be null.");
        Objects.requireNonNull(name, "Product name must not be null.");
        Objects.requireNonNull(unitPrice, "Product unit price must not be null.");
        String normalizedSku = sku.trim().toUpperCase(Locale.ROOT);
        String normalizedName = name.trim();
        if (normalizedSku.isEmpty()) {
            throw new IllegalArgumentException("Product SKU must not be blank.");
        }
        if (normalizedName.isEmpty()) {
            throw new IllegalArgumentException("Product name must not be blank.");
        }
        if (unitPrice.signum() <= 0) {
            throw new IllegalArgumentException("Product unit price must be greater than zero.");
        }
        if (availableStock < 0) {
            throw new IllegalArgumentException("Available stock must not be negative.");
        }
        this.sku = normalizedSku;
        this.name = normalizedName;
        this.unitPrice = unitPrice;
        this.availableStock = availableStock;
    }

    /**
     * Возвращает нормализованный артикул товара.
     *
     * @return артикул в верхнем регистре
     */
    public String getSku() {
        return sku;
    }

    /**
     * Возвращает отображаемое название товара.
     *
     * @return название товара
     */
    public String getName() {
        return name;
    }

    /**
     * Возвращает цену одной единицы товара.
     *
     * @return неизменяемое значение цены за единицу
     */
    public BigDecimal getUnitPrice() {
        return unitPrice;
    }

    /**
     * Возвращает количество единиц, ещё не зарезервированных заказами.
     *
     * @return доступный остаток товара
     */
    public synchronized int getAvailableStock() {
        return availableStock;
    }

    /**
     * Резервирует указанное количество товара для заказа.
     *
     * @param quantity количество резервируемых единиц; должно быть больше нуля
     * @throws IllegalArgumentException если количество некорректно или превышает доступный остаток
     */
    public synchronized void reserve(int quantity) {
        if (quantity <= 0) {
            throw new IllegalArgumentException("Reservation quantity must be greater than zero.");
        }
        if (quantity > availableStock) {
            throw new IllegalArgumentException(
                    "Insufficient stock for product %s: requested %d, available %d."
                            .formatted(sku, quantity, availableStock));
        }
        availableStock -= quantity;
    }

    /**
     * Возвращает на склад единицы товара, зарезервированные отменённым заказом.
     *
     * @param quantity количество возвращаемых единиц; должно быть больше нуля
     * @throws IllegalArgumentException если количество не является положительным
     * @throws ArithmeticException если возврат приведёт к переполнению счётчика остатка
     */
    public synchronized void release(int quantity) {
        if (quantity <= 0) {
            throw new IllegalArgumentException("Release quantity must be greater than zero.");
        }
        availableStock = Math.addExact(availableStock, quantity);
    }
}
