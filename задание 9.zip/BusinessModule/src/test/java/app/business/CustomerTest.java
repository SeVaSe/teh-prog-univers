package app.business;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ValueSource;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

/**
 * Модульные тесты создания покупателя, нормализации данных и проверки идентичности.
 *
 */
@DisplayName("Покупатель")
class CustomerTest {
    /**
     * Проверяет валидацию конструктора и нормализацию данных покупателя.
     *
     */
    @Test
    @DisplayName("проверяет и нормализует данные покупателя")
    void validatesAndNormalizesCustomerData() {
        Customer customer = new Customer("  Ada Lovelace  ", " ADA@example.com ");

        assertEquals("Ada Lovelace", customer.getName());
        assertEquals("ada@example.com", customer.getEmail());
        assertThrows(IllegalArgumentException.class, () -> new Customer("A", "ada@example.com"));
        assertThrows(IllegalArgumentException.class, () -> new Customer("Ada", "not-an-email"));
        assertThrows(NullPointerException.class, () -> new Customer(null, "ada@example.com"));
        assertThrows(NullPointerException.class, () -> new Customer("Ada", null));
    }

    /**
     * Проверяет, что адрес электронной почты определяет идентичность покупателя.
     *
     */
    @Test
    @DisplayName("сравнивает покупателей по нормализованному адресу электронной почты")
    void comparesCustomersByEmail() {
        Customer first = new Customer("Ada", "ADA@example.com");
        Customer sameEmail = new Customer("Different name", "ada@example.com");
        Customer another = new Customer("Ada", "grace@example.com");

        assertEquals(first, sameEmail);
        assertEquals(first.hashCode(), sameEmail.hashCode());
        assertNotEquals(first, another);
        assertNotEquals(first, "ada@example.com");
        assertEquals(first, first);
        assertTrue(first.toString().contains("ada@example.com"));
    }

    /**
     * Проверяет, что некорректные адреса электронной почты отклоняются.
     *
     * @param email адрес, который должен быть отклонён
     */
    @ParameterizedTest(name = "отклоняет адрес: {0}")
    @ValueSource(strings = {"", "plain-text", "missing@domain", "two@@example.com", "has spaces@example.com"})
    void rejectsInvalidEmailAddresses(String email) {
        assertThrows(IllegalArgumentException.class, () -> new Customer("Ada", email));
    }
}
