package app.business;

import org.junit.platform.suite.api.SelectClasses;
import org.junit.platform.suite.api.Suite;

/**
 * Набор JUnit Platform, запускающий все классы тестов бизнес-модуля.
 *
 */
@Suite
@SelectClasses({
        CustomerTest.class,
        ProductTest.class,
        OrderTest.class
})
public class BusinessModuleSuiteTest {
    /**
     * Создаёт описание набора, обнаруживаемое JUnit Platform.
     *
     */
    public BusinessModuleSuiteTest() {
    }
}
