package app.business;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestFactory;
import org.junit.jupiter.api.DynamicTest;

import java.math.BigDecimal;
import java.util.List;
import java.util.function.Consumer;
import java.util.stream.Stream;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.junit.jupiter.api.DynamicTest.dynamicTest;

/**
 * Модульные и динамические тесты стоимости заказа, резервирования товара и состояний заказа.
 *
 */
@DisplayName("Жизненный цикл заказа")
class OrderTest {
    /**
     * Проверяет номер заказа, покупателя, состояние и неизменяемость снимка позиций.
     *
     */
    @Test
    @DisplayName("создаёт пустой черновик заказа")
    void startsAsAnEmptyDraft() {
        Customer customer = customer();
        Order order = new Order(" ORD-1 ", customer);

        assertEquals("ORD-1", order.getOrderNumber());
        assertEquals(customer, order.getCustomer());
        assertEquals(Order.Status.DRAFT, order.getStatus());
        assertEquals(List.of(), order.getItems());
        assertEquals(BigDecimal.ZERO, order.getTotal());
        assertThrows(NullPointerException.class, () -> new Order(null, customer));
        assertThrows(NullPointerException.class, () -> new Order("ORD-2", null));
        assertThrows(IllegalArgumentException.class, () -> new Order(" ", customer));
    }

    /**
     * Проверяет, что добавление товара резервирует остаток, а количества по артикулу суммируются.
     *
     */
    @Test
    @DisplayName("добавляет позиции, суммирует количество и резервирует товар")
    void addsItemsAndReservesStock() {
        Product product = product("WIRE-1", "Copper wire", "2.50", 10);
        Order order = new Order("ORD-2", customer());

        order.addProduct(product, 2);
        order.addProduct(product, 3);

        assertEquals(5, order.getItems().getFirst().quantity());
        assertEquals(new BigDecimal("12.50"), order.getTotal());
        assertEquals(5, product.getAvailableStock());
        assertThrows(UnsupportedOperationException.class, () -> order.getItems().clear());
    }

    /**
     * Проверяет добавление товаров и отсутствие частичного резервирования при ошибке.
     */
    @Test
    @DisplayName("отклоняет некорректные позиции без изменения заказа и остатка")
    void rejectsInvalidItemsWithoutChangingState() {
        Product product = product("WIRE-1", "Copper wire", "2.50", 2);
        Order order = new Order("ORD-3", customer());

        assertThrows(NullPointerException.class, () -> order.addProduct(null, 1));
        assertThrows(IllegalArgumentException.class, () -> order.addProduct(product, 0));
        assertThrows(IllegalArgumentException.class, () -> order.addProduct(product, 3));
        assertEquals(List.of(), order.getItems());
        assertEquals(2, product.getAvailableStock());
    }

    /**
     * Проверяет вычисление стоимости неизменяемой позиции и валидацию её значений.
     *
     */
    @Test
    @DisplayName("вычисляет стоимость позиции заказа")
    void calculatesLineItemTotal() {
        Product product = product("BOLT-1", "Bolt", "1.20", 4);
        Order.LineItem item = new Order.LineItem(product, 3, product.getUnitPrice());

        assertEquals(product, item.product());
        assertEquals(3, item.quantity());
        assertEquals(new BigDecimal("1.20"), item.unitPrice());
        assertEquals(new BigDecimal("3.60"), item.getLineTotal());
        assertThrows(NullPointerException.class, () -> new Order.LineItem(null, 1, BigDecimal.ONE));
        assertThrows(NullPointerException.class, () -> new Order.LineItem(product, 1, null));
        assertThrows(IllegalArgumentException.class, () -> new Order.LineItem(product, 0, BigDecimal.ONE));
        assertThrows(IllegalArgumentException.class, () -> new Order.LineItem(product, 1, BigDecimal.ZERO));
    }

    /**
     * Оформляет непустой заказ и проверяет, что товар остаётся зарезервированным.
     *
     */
    @Test
    @DisplayName("оформляет непустой заказ")
    void placesNonEmptyOrder() {
        Product product = product("BOLT-1", "Bolt", "1.20", 4);
        Order order = new Order("ORD-4", customer());
        assertThrows(IllegalStateException.class, order::place);

        order.addProduct(product, 2);
        order.place();

        assertEquals(Order.Status.PLACED, order.getStatus());
        assertEquals(2, product.getAvailableStock());
    }

    /**
     * Отменяет черновик, возвращает товар на склад и удаляет позиции заказа.
     *
     */
    @Test
    @DisplayName("отменяет черновик и возвращает зарезервированный товар")
    void cancelsDraftAndReturnsStock() {
        Product product = product("BOLT-1", "Bolt", "1.20", 4);
        Order order = new Order("ORD-5", customer());
        order.addProduct(product, 3);

        order.cancel();

        assertEquals(Order.Status.CANCELLED, order.getStatus());
        assertEquals(4, product.getAvailableStock());
        assertTrue(order.getItems().isEmpty());
        assertEquals(BigDecimal.ZERO, order.getTotal());
    }

    /**
     * Проверяет, что товары с одинаковым артикулом в заказе должны быть одним объектом.
     *
     */
    @Test
    @DisplayName("отклоняет другой объект товара с уже использованным артикулом")
    void rejectsDuplicateSkuFromAnotherProductObject() {
        Product original = product("BOLT-1", "Bolt", "1.20", 4);
        Product duplicateSku = product("BOLT-1", "Other bolt", "2.00", 4);
        Order order = new Order("ORD-6", customer());
        order.addProduct(original, 1);

        assertThrows(IllegalArgumentException.class, () -> order.addProduct(duplicateSku, 1));
        assertEquals(3, original.getAvailableStock());
        assertEquals(4, duplicateSku.getAvailableStock());
    }

    /**
     * Создаёт динамические тесты запрещённых переходов для обоих конечных состояний заказа.
     *
     * @return динамические тесты всех недопустимых операций для конечных состояний
     */
    @TestFactory
    @DisplayName("отклоняет изменения после перехода заказа в конечное состояние")
    Stream<DynamicTest> rejectsChangesAfterTerminalStatus() {
        List<NamedChange> changes = List.of(
                new NamedChange("addProduct", order ->
                        order.addProduct(product("EXTRA-1", "Extra", "1.00", 2), 1)),
                new NamedChange("place", Order::place),
                new NamedChange("cancel", Order::cancel));
        return Stream.of(Order.Status.PLACED, Order.Status.CANCELLED)
                .flatMap(status -> changes.stream().map(change ->
                        dynamicTest(status + " order rejects " + change.name(), () -> {
                            Order order = orderInStatus(status);
                            assertThrows(IllegalStateException.class, () -> change.action().accept(order));
                            assertEquals(status, order.getStatus());
                        })));
    }

    private record NamedChange(String name, Consumer<Order> action) {
    }

    private static Order orderInStatus(Order.Status status) {
        Order order = new Order("DYNAMIC-" + status, customer());
        if (status == Order.Status.PLACED) {
            order.addProduct(product("BASE-1", "Base", "1.00", 1), 1);
            order.place();
        } else {
            order.cancel();
        }
        return order;
    }

    private static Customer customer() {
        return new Customer("Ada Lovelace", "ada@example.com");
    }

    private static Product product(String sku, String name, String price, int stock) {
        return new Product(sku, name, new BigDecimal(price), stock);
    }
}
