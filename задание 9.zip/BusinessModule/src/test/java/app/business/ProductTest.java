package app.business;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.RepeatedTest;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ValueSource;

import java.math.BigDecimal;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

/**
 * Модульные тесты проверки товара и синхронизированного изменения складского остатка.
 *
 */
@DisplayName("Складской остаток товара")
class ProductTest {
    /**
     * Проверяет значения товара и корректность нормализованного артикула.
     *
     */
    @Test
    @DisplayName("проверяет товар и возвращает его значения")
    void validatesProductAndExposesValues() {
        Product product = new Product(" sku-01 ", " Copper wire ", new BigDecimal("2.50"), 5);

        assertEquals("SKU-01", product.getSku());
        assertEquals("Copper wire", product.getName());
        assertEquals(new BigDecimal("2.50"), product.getUnitPrice());
        assertEquals(5, product.getAvailableStock());
        assertThrows(NullPointerException.class,
                () -> new Product(null, "Wire", BigDecimal.ONE, 1));
        assertThrows(NullPointerException.class,
                () -> new Product("W-1", null, BigDecimal.ONE, 1));
        assertThrows(NullPointerException.class,
                () -> new Product("W-1", "Wire", null, 1));
        assertThrows(IllegalArgumentException.class,
                () -> new Product(" ", "Wire", BigDecimal.ONE, 1));
        assertThrows(IllegalArgumentException.class,
                () -> new Product("W-1", " ", BigDecimal.ONE, 1));
        assertThrows(IllegalArgumentException.class,
                () -> new Product("W-1", "Wire", BigDecimal.ZERO, 1));
        assertThrows(IllegalArgumentException.class,
                () -> new Product("W-1", "Wire", BigDecimal.ONE, -1));
    }

    /**
     * Проверяет уменьшение остатка при резервировании и увеличение при возврате.
     *
     */
    @Test
    @DisplayName("резервирует товар и возвращает его на склад")
    void reservesAndReleasesInventory() {
        Product product = product(5);

        product.reserve(2);
        assertEquals(3, product.getAvailableStock());
        product.release(1);
        assertEquals(4, product.getAvailableStock());
    }

    /**
     * Проверяет, что некорректное количество для резерва не меняет остаток.
     *
     * @param quantity неположительное количество, которое должно быть отклонено
     */
    @ParameterizedTest(name = "отклоняет количество для резерва: {0}")
    @ValueSource(ints = {0, -1, -20})
    void rejectsNonPositiveReservation(int quantity) {
        Product product = product(5);

        assertThrows(IllegalArgumentException.class, () -> product.reserve(quantity));
        assertEquals(5, product.getAvailableStock());
    }

    /**
     * Повторяет цикл резервирования и возврата, чтобы проверить корректность остатка.
     *
     */
    @RepeatedTest(25)
    @DisplayName("сохраняет остаток при повторных циклах резервирования")
    void preservesStockOverRepeatedReservationCycles() {
        Product product = product(9);

        product.reserve(4);
        assertEquals(5, product.getAvailableStock());
        product.release(4);
        assertEquals(9, product.getAvailableStock());
    }

    /**
     * Проверяет отклонение чрезмерного резерва и некорректного возврата без изменения остатка.
     *
     */
    @Test
    @DisplayName("отклоняет чрезмерный резерв и некорректный возврат")
    void rejectsOverReservationAndInvalidRelease() {
        Product product = product(2);
        Product fullStock = product(Integer.MAX_VALUE);

        assertThrows(IllegalArgumentException.class, () -> product.reserve(3));
        assertThrows(IllegalArgumentException.class, () -> product.release(0));
        assertThrows(ArithmeticException.class, () -> fullStock.release(1));
        assertEquals(2, product.getAvailableStock());
        assertEquals(Integer.MAX_VALUE, fullStock.getAvailableStock());
    }

    private static Product product(int stock) {
        return new Product("WIRE-1", "Copper wire", new BigDecimal("2.50"), stock);
    }
}
