package app.calculators.web;

import app.calculators.web.domain.UserRole;
import app.calculators.web.repository.OperationHistoryRepository;
import app.calculators.web.repository.UserRepository;
import app.calculators.web.service.AdminService;
import app.calculators.web.service.CalculatorService;
import app.calculators.web.service.RegistrationService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.security.test.context.support.WithMockUser;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.springframework.security.test.web.servlet.request.SecurityMockMvcRequestPostProcessors.csrf;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@SpringBootTest
@AutoConfigureMockMvc
@Transactional
class CalculatorsIntegrationTest {
    @Autowired
    private MockMvc mvc;

    @Autowired
    private RegistrationService registration;

    @Autowired
    private CalculatorService calculators;

    @Autowired
    private AdminService admins;

    @Autowired
    private UserRepository users;

    @Autowired
    private OperationHistoryRepository history;

    @BeforeEach
    void createAccounts() {
        if (!users.existsByUsername("testadmin")) {
            registration.createFirstAdministrator("testadmin", "admin-password-123");
        }
        if (!users.existsByUsername("testuser")) {
            registration.register("testuser", "user-password-123");
        }
    }

    @Test
    void userCanCalculateAndOnlyTheirOperationsAppearInTheirHistory() {
        BigDecimal converted = calculators.convert("testuser", new BigDecimal("10"), "USD", "EUR");
        BigDecimal voltage = calculators.calculateOhm(
                "testuser", "V", null, new BigDecimal("2"), new BigDecimal("10"));
        BigDecimal current = calculators.calculateOhm(
                "testuser", "I", new BigDecimal("20"), null, new BigDecimal("10"));
        BigDecimal resistance = calculators.calculateOhm(
                "testuser", "R", new BigDecimal("20"), new BigDecimal("2"), null);

        assertThat(converted).isEqualByComparingTo("9.20");
        assertThat(voltage).isEqualByComparingTo("20");
        assertThat(current).isEqualByComparingTo("2");
        assertThat(resistance).isEqualByComparingTo("10");
        assertThat(calculators.getUserHistory("testuser")).hasSize(4);
        assertThat(calculators.getUserHistory("testadmin")).isEmpty();
        assertThat(calculators.getAllHistory()).hasSize(4);
    }

    @Test
    void ohmCalculatorRequiresExactlyTheSelectedUnknown() {
        assertThatThrownBy(() -> calculators.calculateOhm(
                "testuser", "V", new BigDecimal("10"), new BigDecimal("2"), new BigDecimal("5")))
                .isInstanceOf(IllegalArgumentException.class)
                .hasMessageContaining("Оставьте пустым только поле V");
    }

    @Test
    void adminsCanChangeRatesAndRateChangesAreRecorded() {
        calculators.saveRate("testadmin", "GBP", "Фунт стерлингов", new BigDecimal("0.8"));

        assertThat(calculators.getRates()).anySatisfy(rate -> {
            assertThat(rate.getCode()).isEqualTo("GBP");
            assertThat(rate.getUnitsPerUsd()).isEqualByComparingTo("0.8");
        });
        assertThat(calculators.getUserHistory("testadmin")).hasSize(1);
    }

    @Test
    void cannotDisableOrDemoteTheOnlyActiveAdmin() {
        long adminId = users.findByUsername("testadmin").orElseThrow().getId();

        assertThatThrownBy(() -> admins.setEnabled(adminId, false, "testuser"))
                .isInstanceOf(IllegalArgumentException.class)
                .hasMessageContaining("последнего активного администратора");
        assertThatThrownBy(() -> admins.setRole(adminId, UserRole.USER, "testuser"))
                .isInstanceOf(IllegalArgumentException.class)
                .hasMessageContaining("активный администратор");
    }

    @Test
    @WithMockUser(username = "testuser", roles = "USER")
    void regularUsersCannotOpenAdministratorPages() throws Exception {
        mvc.perform(get("/admin/history"))
                .andExpect(status().is3xxRedirection())
                .andExpect(redirectedUrl("/?denied"));
    }

    @Test
    @WithMockUser(username = "testadmin", roles = "ADMIN")
    void administratorCanOpenAllHistory() throws Exception {
        mvc.perform(get("/admin/history"))
                .andExpect(status().isOk())
                .andExpect(view().name("history"))
                .andExpect(model().attribute("allHistory", true));
    }

    @Test
    @WithMockUser(username = "testuser", roles = "USER")
    void dashboardTemplateRendersForRegularUsers() throws Exception {
        mvc.perform(get("/"))
                .andExpect(status().isOk())
                .andExpect(view().name("dashboard"))
                .andExpect(content().string(org.hamcrest.Matchers.containsString("Конвертер валют")))
                .andExpect(content().string(org.hamcrest.Matchers.containsString("Закон Ома")));
    }

    @Test
    @WithMockUser(username = "testadmin", roles = "ADMIN")
    void administratorManagementPagesRender() throws Exception {
        mvc.perform(get("/admin/users"))
                .andExpect(status().isOk())
                .andExpect(view().name("admin/users"))
                .andExpect(content().string(org.hamcrest.Matchers.containsString("testuser")));
        mvc.perform(get("/admin/rates"))
                .andExpect(status().isOk())
                .andExpect(view().name("admin/rates"))
                .andExpect(content().string(org.hamcrest.Matchers.containsString("EUR")));
    }

    @Test
    void unauthenticatedUsersAreRedirectedToLogin() throws Exception {
        mvc.perform(get("/history"))
                .andExpect(status().is3xxRedirection())
                .andExpect(redirectedUrlPattern("**/login"));
    }

    @Test
    void authenticationPagesRenderOrRedirectAsExpected() throws Exception {
        mvc.perform(get("/login"))
                .andExpect(status().isOk())
                .andExpect(view().name("auth/login"));
        mvc.perform(get("/setup"))
                .andExpect(status().is3xxRedirection())
                .andExpect(redirectedUrl("/login"));
        mvc.perform(get("/register"))
                .andExpect(status().isOk())
                .andExpect(view().name("auth/register"));
    }

    @Test
    void firstRunOffersAdminSetupBeforeLogin() throws Exception {
        users.delete(users.findByUsername("testadmin").orElseThrow());

        mvc.perform(get("/"))
                .andExpect(status().is3xxRedirection())
                .andExpect(redirectedUrl("/setup"));
        mvc.perform(get("/setup"))
                .andExpect(status().isOk())
                .andExpect(view().name("auth/setup"));
        mvc.perform(post("/setup")
                        .with(csrf())
                        .param("username", "firstadmin")
                        .param("password", "first-admin-password")
                        .param("confirmPassword", "first-admin-password"))
                .andExpect(status().is3xxRedirection())
                .andExpect(redirectedUrl("/login"));
        assertThat(users.findByUsername("firstadmin").orElseThrow().getRole())
                .isEqualTo(UserRole.ADMIN);
    }

    @Test
    void anonymousDashboardRedirectsToLoginAfterSetup() throws Exception {
        mvc.perform(get("/"))
                .andExpect(status().is3xxRedirection())
                .andExpect(redirectedUrl("/login"));
    }

    @Test
    void publicRegistrationAlwaysCreatesARegularUser() throws Exception {
        mvc.perform(post("/register")
                        .with(csrf())
                        .param("username", "newwebuser")
                        .param("password", "new-user-password")
                        .param("confirmPassword", "new-user-password"))
                .andExpect(status().isOk())
                .andExpect(view().name("auth/login"));

        assertThat(users.findByUsername("newwebuser").orElseThrow().getRole())
                .isEqualTo(UserRole.USER);
    }

    @Test
    void loginFormAuthenticatesStoredAccount() throws Exception {
        mvc.perform(post("/login")
                        .with(csrf())
                        .param("username", "testuser")
                        .param("password", "user-password-123"))
                .andExpect(status().is3xxRedirection())
                .andExpect(redirectedUrl("/"));
    }

    @Test
    @WithMockUser(username = "testuser", roles = "USER")
    void calculatorPostSavesOperationAndRendersResult() throws Exception {
        mvc.perform(post("/calculator/currency")
                        .with(csrf())
                        .param("amount", "10")
                        .param("fromCode", "USD")
                        .param("toCode", "EUR"))
                .andExpect(status().isOk())
                .andExpect(view().name("dashboard"))
                .andExpect(content().string(org.hamcrest.Matchers.containsString("10 USD = 9.2 EUR")));

        assertThat(calculators.getUserHistory("testuser")).hasSize(1);
    }
}
