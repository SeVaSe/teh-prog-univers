package app.calculators.web.service;

import app.calculators.web.domain.AppUser;
import app.calculators.web.domain.UserRole;
import app.calculators.web.repository.UserRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
public class AdminService {
    private final UserRepository users;

    public AdminService(UserRepository users) {
        this.users = users;
    }

    @Transactional(readOnly = true)
    public List<AppUser> getUsers() {
        return users.findAllByOrderByCreatedAtDesc();
    }

    @Transactional
    public void setEnabled(long userId, boolean enabled, String actor) {
        AppUser user = findUser(userId);
        if (user.getUsername().equals(actor) && !enabled) {
            throw new IllegalArgumentException("Нельзя заблокировать собственную учётную запись.");
        }
        if (!enabled && user.getRole() == UserRole.ADMIN && user.isEnabled()
                && users.countByRoleAndEnabledTrue(UserRole.ADMIN) <= 1) {
            throw new IllegalArgumentException("Нельзя заблокировать последнего активного администратора.");
        }
        user.setEnabled(enabled);
    }

    @Transactional
    public void setRole(long userId, UserRole role, String actor) {
        AppUser user = findUser(userId);
        if (user.getUsername().equals(actor) && role != UserRole.ADMIN) {
            throw new IllegalArgumentException("Нельзя снять роль администратора со своей учётной записи.");
        }
        if (user.getRole() == UserRole.ADMIN && role != UserRole.ADMIN && user.isEnabled()
                && users.countByRoleAndEnabledTrue(UserRole.ADMIN) <= 1) {
            throw new IllegalArgumentException("В системе должен остаться хотя бы один активный администратор.");
        }
        user.setRole(role);
    }

    private AppUser findUser(long id) {
        return users.findById(id).orElseThrow(() -> new IllegalArgumentException("Пользователь не найден."));
    }
}
