package app.calculators.web.controller;

import app.calculators.web.form.RegistrationForm;
import app.calculators.web.service.RegistrationService;
import jakarta.validation.Valid;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.security.core.Authentication;
import org.springframework.security.authentication.AnonymousAuthenticationToken;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.util.Objects;

@Controller
public class AuthController {
    private final RegistrationService registration;

    public AuthController(RegistrationService registration) {
        this.registration = registration;
    }

    @GetMapping("/login")
    public String login(Authentication authentication) {
        return isAuthenticated(authentication) ? "redirect:/" : "auth/login";
    }

    @GetMapping("/register")
    public String registerPage(Model model) {
        model.addAttribute("registrationForm", new RegistrationForm());
        return "auth/register";
    }

    @PostMapping("/register")
    public String register(@Valid @ModelAttribute("registrationForm") RegistrationForm form,
                           BindingResult bindingResult, Model model) {
        if (!Objects.equals(form.getPassword(), form.getConfirmPassword())) {
            bindingResult.rejectValue("confirmPassword", "password.mismatch", "Пароли не совпадают.");
        }
        if (bindingResult.hasErrors()) {
            return "auth/register";
        }
        try {
            registration.register(form.getUsername(), form.getPassword());
            model.addAttribute("successMessage", "Учётная запись создана. Теперь войдите.");
            return "auth/login";
        } catch (DataIntegrityViolationException exception) {
            bindingResult.rejectValue("username", "username.duplicate", "Такое имя пользователя уже занято.");
            return "auth/register";
        } catch (IllegalArgumentException exception) {
            bindingResult.rejectValue("username", "username.invalid", exception.getMessage());
            return "auth/register";
        }
    }

    @GetMapping("/setup")
    public String setupPage(Authentication authentication, Model model) {
        if (isAuthenticated(authentication)) {
            return "redirect:/";
        }
        if (registration.hasAdministrator()) {
            return "redirect:/login";
        }
        model.addAttribute("registrationForm", new RegistrationForm());
        return "auth/setup";
    }

    @PostMapping("/setup")
    public String setup(@Valid @ModelAttribute("registrationForm") RegistrationForm form,
                        BindingResult bindingResult, Model model, RedirectAttributes redirect) {
        if (!Objects.equals(form.getPassword(), form.getConfirmPassword())) {
            bindingResult.rejectValue("confirmPassword", "password.mismatch", "Пароли не совпадают.");
        }
        if (bindingResult.hasErrors()) {
            return "auth/setup";
        }
        try {
            registration.createFirstAdministrator(form.getUsername(), form.getPassword());
            redirect.addFlashAttribute("successMessage", "Администратор создан. Войдите в систему.");
            return "redirect:/login";
        } catch (DataIntegrityViolationException exception) {
            bindingResult.rejectValue("username", "username.duplicate", "Имя пользователя уже используется.");
            return "auth/setup";
        } catch (IllegalStateException exception) {
            return "redirect:/login";
        } catch (IllegalArgumentException exception) {
            bindingResult.rejectValue("username", "username.invalid", exception.getMessage());
            return "auth/setup";
        }
    }

    private boolean isAuthenticated(Authentication authentication) {
        return authentication != null && authentication.isAuthenticated()
                && !(authentication instanceof AnonymousAuthenticationToken);
    }
}
