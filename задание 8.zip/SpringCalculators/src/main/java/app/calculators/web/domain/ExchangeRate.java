package app.calculators.web.domain;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.PrePersist;
import jakarta.persistence.PreUpdate;
import jakarta.persistence.Table;

import java.math.BigDecimal;
import java.time.Instant;

@Entity
@Table(name = "exchange_rates")
public class ExchangeRate {
    @Id
    @Column(length = 3)
    private String code;

    @Column(nullable = false, length = 60)
    private String name;

    @Column(nullable = false, precision = 24, scale = 10)
    private BigDecimal unitsPerUsd;

    @Column(nullable = false)
    private Instant updatedAt;

    @Column(nullable = false, length = 40)
    private String updatedBy;

    protected ExchangeRate() {
    }

    public ExchangeRate(String code, String name, BigDecimal unitsPerUsd, String updatedBy) {
        this.code = code;
        this.name = name;
        this.unitsPerUsd = unitsPerUsd;
        this.updatedBy = updatedBy;
    }

    @PrePersist
    @PreUpdate
    void updateTimestamp() {
        updatedAt = Instant.now();
    }

    public String getCode() {
        return code;
    }

    public String getName() {
        return name;
    }

    public BigDecimal getUnitsPerUsd() {
        return unitsPerUsd;
    }

    public Instant getUpdatedAt() {
        return updatedAt;
    }

    public String getUpdatedBy() {
        return updatedBy;
    }

    public void update(String name, BigDecimal unitsPerUsd, String updatedBy) {
        this.name = name;
        this.unitsPerUsd = unitsPerUsd;
        this.updatedBy = updatedBy;
    }
}
