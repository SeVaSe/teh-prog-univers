package app.calculators.web.controller;

import app.calculators.web.form.CalculatorForms;
import app.calculators.web.service.CalculatorService;
import app.calculators.web.service.RegistrationService;
import org.springframework.security.authentication.AnonymousAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class DashboardController {
    private final CalculatorService calculators;
    private final RegistrationService registration;

    public DashboardController(CalculatorService calculators, RegistrationService registration) {
        this.calculators = calculators;
        this.registration = registration;
    }

    @GetMapping("/")
    public String dashboard(Authentication authentication, Model model,
                            @RequestParam(required = false) String denied) {
        if (!registration.hasAdministrator()) {
            return "redirect:/setup";
        }
        if (authentication == null || !authentication.isAuthenticated()
                || authentication instanceof AnonymousAuthenticationToken) {
            return "redirect:/login";
        }
        model.addAttribute("rates", calculators.getRates());
        model.addAttribute("currencyForm", new CalculatorForms.Currency());
        model.addAttribute("ohmForm", new CalculatorForms.Ohm());
        model.addAttribute("username", authentication.getName());
        model.addAttribute("isAdmin", authentication.getAuthorities().stream()
                .anyMatch(authority -> authority.getAuthority().equals("ROLE_ADMIN")));
        if (denied != null) {
            model.addAttribute("errorMessage", "У вас нет доступа к этой странице.");
        }
        return "dashboard";
    }
}
