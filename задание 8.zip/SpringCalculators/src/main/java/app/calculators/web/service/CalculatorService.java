package app.calculators.web.service;

import app.calculators.web.domain.ExchangeRate;
import app.calculators.web.domain.OperationHistory;
import app.calculators.web.repository.ExchangeRateRepository;
import app.calculators.web.repository.OperationHistoryRepository;
import app.calculators.web.repository.UserRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.math.MathContext;
import java.math.RoundingMode;
import java.util.List;
import java.util.Locale;

@Service
public class CalculatorService {
    private static final MathContext MATH_CONTEXT = MathContext.DECIMAL128;
    private final ExchangeRateRepository rates;
    private final OperationHistoryRepository history;
    private final UserRepository users;

    public CalculatorService(ExchangeRateRepository rates, OperationHistoryRepository history, UserRepository users) {
        this.rates = rates;
        this.history = history;
        this.users = users;
    }

    public List<ExchangeRate> getRates() {
        return rates.findAllByOrderByCodeAsc();
    }

    @Transactional
    public BigDecimal convert(String username, BigDecimal amount, String fromCode, String toCode) {
        if (amount == null || amount.signum() <= 0) {
            throw new IllegalArgumentException("Сумма должна быть больше нуля.");
        }
        ExchangeRate from = rates.findById(fromCode)
                .orElseThrow(() -> new IllegalArgumentException("Исходная валюта не найдена."));
        ExchangeRate to = rates.findById(toCode)
                .orElseThrow(() -> new IllegalArgumentException("Целевая валюта не найдена."));
        BigDecimal converted = amount.divide(from.getUnitsPerUsd(), MATH_CONTEXT)
                .multiply(to.getUnitsPerUsd(), MATH_CONTEXT);
        saveOperation(username, "Конвертация валют",
                amount.stripTrailingZeros().toPlainString() + " " + fromCode + " → " + toCode,
                converted.setScale(4, RoundingMode.HALF_UP).stripTrailingZeros().toPlainString() + " " + toCode);
        return converted;
    }

    @Transactional
    public BigDecimal calculateOhm(String username, String unknown, BigDecimal voltage,
                                   BigDecimal current, BigDecimal resistance) {
        if (unknown == null || !List.of("V", "I", "R").contains(unknown)) {
            throw new IllegalArgumentException("Выберите величину, которую нужно вычислить.");
        }
        int missing = (voltage == null ? 1 : 0) + (current == null ? 1 : 0) + (resistance == null ? 1 : 0);
        String missingValue = voltage == null ? "V" : current == null ? "I" : resistance == null ? "R" : "";
        if (missing != 1 || !unknown.equals(missingValue)) {
            throw new IllegalArgumentException("Оставьте пустым только поле " + unknown
                    + " и заполните две остальные величины.");
        }
        if (voltage != null) validatePositive(voltage, "Напряжение V");
        if (current != null) validatePositive(current, "Ток I");
        if (resistance != null) validatePositive(resistance, "Сопротивление R");

        BigDecimal value = switch (unknown) {
            case "V" -> current.multiply(resistance, MATH_CONTEXT);
            case "I" -> voltage.divide(resistance, MATH_CONTEXT);
            case "R" -> voltage.divide(current, MATH_CONTEXT);
            default -> throw new IllegalArgumentException("Неизвестная величина.");
        };
        if (value.signum() <= 0) {
            throw new IllegalArgumentException("Результат должен быть больше нуля.");
        }
        String details = switch (unknown) {
            case "V" -> "I = " + current.toPlainString() + " A, R = " + resistance.toPlainString() + " Ω";
            case "I" -> "V = " + voltage.toPlainString() + " V, R = " + resistance.toPlainString() + " Ω";
            case "R" -> "V = " + voltage.toPlainString() + " V, I = " + current.toPlainString() + " A";
            default -> throw new IllegalArgumentException("Неизвестная величина.");
        };
        String unit = switch (unknown) {
            case "V" -> "V";
            case "I" -> "A";
            case "R" -> "Ω";
            default -> throw new IllegalArgumentException("Неизвестная величина.");
        };
        saveOperation(username, "Закон Ома", details, unknown + " = " + value.stripTrailingZeros().toPlainString() + " " + unit);
        return value;
    }

    @Transactional
    public void saveRate(String username, String code, String name, BigDecimal unitsPerUsd) {
        String normalizedCode = code.trim().toUpperCase(Locale.ROOT);
        if (!normalizedCode.matches("[A-Z]{3}")) {
            throw new IllegalArgumentException("Код валюты должен состоять из трёх латинских букв.");
        }
        if (name == null || name.isBlank() || name.trim().length() > 60) {
            throw new IllegalArgumentException("Укажите название валюты длиной от 1 до 60 символов.");
        }
        validatePositive(unitsPerUsd, "Курс");
        if ("USD".equals(normalizedCode) && unitsPerUsd.compareTo(BigDecimal.ONE) != 0) {
            throw new IllegalArgumentException("Курс USD фиксирован на уровне 1.");
        }
        ExchangeRate rate = rates.findById(normalizedCode)
                .orElseGet(() -> new ExchangeRate(normalizedCode, name.trim(), unitsPerUsd, username));
        rate.update(name.trim(), unitsPerUsd, username);
        rates.save(rate);
        saveOperation(username, "Изменение курса",
                normalizedCode + " — " + name.trim(),
                "1 USD = " + unitsPerUsd.stripTrailingZeros().toPlainString() + " " + normalizedCode);
    }

    public List<OperationHistory> getUserHistory(String username) {
        return history.findByUsernameOrderByCreatedAtDesc(username);
    }

    public List<OperationHistory> getAllHistory() {
        return history.findAllByOrderByCreatedAtDesc();
    }

    private void validatePositive(BigDecimal value, String label) {
        if (value == null || value.signum() <= 0) {
            throw new IllegalArgumentException(label + " должно быть больше нуля.");
        }
    }

    private void saveOperation(String username, String type, String details, String result) {
        if (!users.existsByUsername(username)) {
            throw new IllegalArgumentException("Пользователь не найден.");
        }
        history.save(new OperationHistory(username, type, details, result));
    }
}
