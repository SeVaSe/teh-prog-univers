package app.calculators.web.repository;

import app.calculators.web.domain.AppUser;
import app.calculators.web.domain.UserRole;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;

public interface UserRepository extends JpaRepository<AppUser, Long> {
    Optional<AppUser> findByUsername(String username);

    boolean existsByUsername(String username);

    long countByRole(UserRole role);

    long countByRoleAndEnabledTrue(UserRole role);

    List<AppUser> findAllByOrderByCreatedAtDesc();
}
