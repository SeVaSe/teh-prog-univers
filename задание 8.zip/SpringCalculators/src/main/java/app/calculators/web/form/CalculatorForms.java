package app.calculators.web.form;

import jakarta.validation.constraints.DecimalMin;
import jakarta.validation.constraints.Digits;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;

import java.math.BigDecimal;

public final class CalculatorForms {
    private CalculatorForms() {
    }

    public static class Currency {
        @DecimalMin(value = "0", inclusive = false, message = "Сумма должна быть больше нуля.")
        @Digits(integer = 18, fraction = 8, message = "Введите сумму с точностью до 8 знаков.")
        private BigDecimal amount;

        @NotBlank(message = "Выберите исходную валюту.")
        @Pattern(regexp = "[A-Z]{3}", message = "Неверный код валюты.")
        private String fromCode;

        @NotBlank(message = "Выберите целевую валюту.")
        @Pattern(regexp = "[A-Z]{3}", message = "Неверный код валюты.")
        private String toCode;

        public BigDecimal getAmount() { return amount; }
        public void setAmount(BigDecimal amount) { this.amount = amount; }
        public String getFromCode() { return fromCode; }
        public void setFromCode(String fromCode) { this.fromCode = fromCode; }
        public String getToCode() { return toCode; }
        public void setToCode(String toCode) { this.toCode = toCode; }
    }

    public static class Ohm {
        @NotBlank(message = "Выберите неизвестную величину.")
        @Pattern(regexp = "V|I|R", message = "Неизвестная величина должна быть V, I или R.")
        private String unknown;

        @DecimalMin(value = "0", inclusive = false, message = "Напряжение должно быть больше нуля.")
        @Digits(integer = 18, fraction = 8, message = "Введите напряжение с точностью до 8 знаков.")
        private BigDecimal voltage;

        @DecimalMin(value = "0", inclusive = false, message = "Ток должен быть больше нуля.")
        @Digits(integer = 18, fraction = 8, message = "Введите ток с точностью до 8 знаков.")
        private BigDecimal current;

        @DecimalMin(value = "0", inclusive = false, message = "Сопротивление должно быть больше нуля.")
        @Digits(integer = 18, fraction = 8, message = "Введите сопротивление с точностью до 8 знаков.")
        private BigDecimal resistance;

        public String getUnknown() { return unknown; }
        public void setUnknown(String unknown) { this.unknown = unknown; }
        public BigDecimal getVoltage() { return voltage; }
        public void setVoltage(BigDecimal voltage) { this.voltage = voltage; }
        public BigDecimal getCurrent() { return current; }
        public void setCurrent(BigDecimal current) { this.current = current; }
        public BigDecimal getResistance() { return resistance; }
        public void setResistance(BigDecimal resistance) { this.resistance = resistance; }
    }

    public static class Rate {
        @NotBlank(message = "Укажите код валюты.")
        @Pattern(regexp = "[A-Za-z]{3}", message = "Код валюты должен состоять из трёх латинских букв.")
        private String code;

        @NotBlank(message = "Укажите название валюты.")
        @Size(max = 60, message = "Название должно быть не длиннее 60 символов.")
        private String name;

        @DecimalMin(value = "0", inclusive = false, message = "Курс должен быть больше нуля.")
        @Digits(integer = 14, fraction = 10, message = "Точность курса: до 10 знаков после запятой.")
        private BigDecimal unitsPerUsd;

        public String getCode() { return code; }
        public void setCode(String code) { this.code = code; }
        public String getName() { return name; }
        public void setName(String name) { this.name = name; }
        public BigDecimal getUnitsPerUsd() { return unitsPerUsd; }
        public void setUnitsPerUsd(BigDecimal unitsPerUsd) { this.unitsPerUsd = unitsPerUsd; }
    }
}
