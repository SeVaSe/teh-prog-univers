package app.calculators.web.controller;

import app.calculators.web.domain.UserRole;
import app.calculators.web.form.CalculatorForms;
import app.calculators.web.service.AdminService;
import app.calculators.web.service.CalculatorService;
import jakarta.validation.Valid;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

@Controller
@RequestMapping("/admin")
public class AdminController {
    private final AdminService adminService;
    private final CalculatorService calculatorService;

    public AdminController(AdminService adminService, CalculatorService calculatorService) {
        this.adminService = adminService;
        this.calculatorService = calculatorService;
    }

    @GetMapping("/users")
    public String users(Model model) {
        model.addAttribute("users", adminService.getUsers());
        return "admin/users";
    }

    @PostMapping("/users/{id}/enabled")
    public String setEnabled(@PathVariable long id, @RequestParam boolean enabled,
                             Authentication authentication, RedirectAttributes redirect) {
        try {
            adminService.setEnabled(id, enabled, authentication.getName());
            redirect.addFlashAttribute("successMessage", "Статус пользователя изменён.");
        } catch (IllegalArgumentException exception) {
            redirect.addFlashAttribute("errorMessage", exception.getMessage());
        }
        return "redirect:/admin/users";
    }

    @PostMapping("/users/{id}/role")
    public String setRole(@PathVariable long id, @RequestParam String role,
                          Authentication authentication, RedirectAttributes redirect) {
        try {
            adminService.setRole(id, UserRole.valueOf(role), authentication.getName());
            redirect.addFlashAttribute("successMessage", "Роль пользователя изменена.");
        } catch (IllegalArgumentException exception) {
            redirect.addFlashAttribute("errorMessage", "Не удалось изменить роль: " + exception.getMessage());
        }
        return "redirect:/admin/users";
    }

    @GetMapping("/history")
    public String history(Model model) {
        model.addAttribute("entries", calculatorService.getAllHistory());
        model.addAttribute("pageTitle", "История всех пользователей");
        model.addAttribute("allHistory", true);
        return "history";
    }

    @GetMapping("/rates")
    public String rates(Model model) {
        model.addAttribute("rates", calculatorService.getRates());
        model.addAttribute("rateForm", new CalculatorForms.Rate());
        return "admin/rates";
    }

    @PostMapping("/rates")
    public String saveRate(@Valid CalculatorForms.Rate form, BindingResult bindingResult,
                           Authentication authentication, Model model, RedirectAttributes redirect) {
        if (bindingResult.hasErrors()) {
            model.addAttribute("rates", calculatorService.getRates());
            model.addAttribute("formError", bindingResult.getFieldErrors().getFirst().getDefaultMessage());
            return "admin/rates";
        }
        try {
            calculatorService.saveRate(authentication.getName(), form.getCode(),
                    form.getName(), form.getUnitsPerUsd());
            redirect.addFlashAttribute("successMessage", "Курс валюты сохранён.");
            return "redirect:/admin/rates";
        } catch (IllegalArgumentException exception) {
            model.addAttribute("rates", calculatorService.getRates());
            model.addAttribute("formError", exception.getMessage());
            return "admin/rates";
        }
    }
}
