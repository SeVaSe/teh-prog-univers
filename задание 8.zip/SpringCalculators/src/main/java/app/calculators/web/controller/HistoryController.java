package app.calculators.web.controller;

import app.calculators.web.service.CalculatorService;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class HistoryController {
    private final CalculatorService calculators;

    public HistoryController(CalculatorService calculators) {
        this.calculators = calculators;
    }

    @GetMapping("/history")
    public String history(Authentication authentication, Model model) {
        model.addAttribute("entries", calculators.getUserHistory(authentication.getName()));
        model.addAttribute("pageTitle", "Моя история вычислений");
        model.addAttribute("allHistory", false);
        return "history";
    }
}
