package app.calculators.web.repository;

import app.calculators.web.domain.OperationHistory;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface OperationHistoryRepository extends JpaRepository<OperationHistory, Long> {
    List<OperationHistory> findByUsernameOrderByCreatedAtDesc(String username);

    List<OperationHistory> findAllByOrderByCreatedAtDesc();
}
