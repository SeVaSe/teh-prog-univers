package app.calculators.web.repository;

import app.calculators.web.domain.AdminSetupGuard;
import jakarta.persistence.LockModeType;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Lock;
import org.springframework.data.jpa.repository.Query;

import java.util.Optional;

public interface AdminSetupGuardRepository extends JpaRepository<AdminSetupGuard, Integer> {
    @Lock(LockModeType.PESSIMISTIC_WRITE)
    @Query("select guard from AdminSetupGuard guard where guard.id = 1")
    Optional<AdminSetupGuard> lockSetup();
}
