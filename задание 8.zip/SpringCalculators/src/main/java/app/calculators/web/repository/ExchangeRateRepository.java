package app.calculators.web.repository;

import app.calculators.web.domain.ExchangeRate;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface ExchangeRateRepository extends JpaRepository<ExchangeRate, String> {
    List<ExchangeRate> findAllByOrderByCodeAsc();
}
