package app.calculators.web;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CalculatorsWebApplication {
    public static void main(String[] args) {
        SpringApplication.run(CalculatorsWebApplication.class, args);
    }
}
