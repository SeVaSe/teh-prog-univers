package app.calculators.web.form;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;

public class RegistrationForm {
    @NotBlank
    @Pattern(regexp = "[A-Za-z0-9_.-]{3,40}", message = "Используйте 3–40 латинских букв, цифр или символов . _ -")
    private String username;

    @NotBlank
    @Size(min = 8, max = 128, message = "Пароль должен содержать 8–128 символов.")
    private String password;

    @NotBlank
    private String confirmPassword;

    public String getUsername() { return username; }
    public void setUsername(String username) { this.username = username; }
    public String getPassword() { return password; }
    public void setPassword(String password) { this.password = password; }
    public String getConfirmPassword() { return confirmPassword; }
    public void setConfirmPassword(String confirmPassword) { this.confirmPassword = confirmPassword; }
}
