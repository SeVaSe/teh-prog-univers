package app.calculators.web.domain;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "admin_setup_guard")
public class AdminSetupGuard {
    @Id
    private Integer id;

    protected AdminSetupGuard() {
    }

    public AdminSetupGuard(Integer id) {
        this.id = id;
    }
}
