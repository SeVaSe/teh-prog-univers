package app.calculators.web.domain;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.PrePersist;
import jakarta.persistence.Table;

import java.time.Instant;

@Entity
@Table(name = "operation_history")
public class OperationHistory {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false, length = 40)
    private String username;

    @Column(nullable = false, length = 30)
    private String operationType;

    @Column(nullable = false, length = 500)
    private String details;

    @Column(nullable = false, length = 300)
    private String result;

    @Column(nullable = false, updatable = false)
    private Instant createdAt;

    protected OperationHistory() {
    }

    public OperationHistory(String username, String operationType, String details, String result) {
        this.username = username;
        this.operationType = operationType;
        this.details = details;
        this.result = result;
    }

    @PrePersist
    void onCreate() {
        createdAt = Instant.now();
    }

    public String getUsername() {
        return username;
    }

    public String getOperationType() {
        return operationType;
    }

    public String getDetails() {
        return details;
    }

    public String getResult() {
        return result;
    }

    public Instant getCreatedAt() {
        return createdAt;
    }
}
