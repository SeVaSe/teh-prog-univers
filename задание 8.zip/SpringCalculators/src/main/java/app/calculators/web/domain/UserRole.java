package app.calculators.web.domain;

public enum UserRole {
    ADMIN,
    USER
}
