package app.calculators.web.service;

import app.calculators.web.domain.AppUser;
import app.calculators.web.domain.UserRole;
import app.calculators.web.repository.AdminSetupGuardRepository;
import app.calculators.web.repository.UserRepository;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class RegistrationService {
    private final UserRepository users;
    private final AdminSetupGuardRepository setupGuards;
    private final PasswordEncoder passwordEncoder;

    public RegistrationService(UserRepository users, AdminSetupGuardRepository setupGuards,
                               PasswordEncoder passwordEncoder) {
        this.users = users;
        this.setupGuards = setupGuards;
        this.passwordEncoder = passwordEncoder;
    }

    @Transactional(readOnly = true)
    public boolean hasAdministrator() {
        return users.countByRole(UserRole.ADMIN) > 0;
    }

    @Transactional
    public void register(String username, String password) {
        String normalizedUsername = username.trim();
        if (users.existsByUsername(normalizedUsername)) {
            throw new IllegalArgumentException("Такое имя пользователя уже занято.");
        }
        users.save(new AppUser(normalizedUsername, passwordEncoder.encode(password), UserRole.USER));
    }

    @Transactional
    public void createFirstAdministrator(String username, String password) {
        setupGuards.lockSetup().orElseThrow(
                () -> new IllegalStateException("Не удалось получить блокировку первоначальной настройки."));
        if (users.countByRole(UserRole.ADMIN) != 0) {
            throw new IllegalStateException("Первый администратор уже создан.");
        }
        String normalizedUsername = username.trim();
        if (users.existsByUsername(normalizedUsername)) {
            throw new IllegalArgumentException("Такое имя пользователя уже занято.");
        }
        users.save(new AppUser(normalizedUsername, passwordEncoder.encode(password), UserRole.ADMIN));
    }
}
