package app.calculators.web.controller;

import app.calculators.web.form.CalculatorForms;
import app.calculators.web.service.CalculatorService;
import jakarta.validation.Valid;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import java.math.RoundingMode;

@Controller
@RequestMapping("/calculator")
public class CalculatorController {
    private final CalculatorService calculators;

    public CalculatorController(CalculatorService calculators) {
        this.calculators = calculators;
    }

    @PostMapping("/currency")
    public String convert(@Valid CalculatorForms.Currency form, BindingResult bindingResult,
                          Authentication authentication, Model model) {
        if (bindingResult.hasErrors()) {
            return invalidForm("Валюта", bindingResult.getFieldErrors().getFirst().getDefaultMessage(), authentication, model);
        }
        try {
            var result = calculators.convert(authentication.getName(), form.getAmount(),
                    form.getFromCode(), form.getToCode());
            model.addAttribute("currencyResult", form.getAmount().stripTrailingZeros().toPlainString()
                    + " " + form.getFromCode() + " = "
                    + result.setScale(4, RoundingMode.HALF_UP).stripTrailingZeros().toPlainString()
                    + " " + form.getToCode());
            return dashboard(authentication, model);
        } catch (IllegalArgumentException exception) {
            return invalidForm("Валюта", exception.getMessage(), authentication, model);
        }
    }

    @PostMapping("/ohm")
    public String calculateOhm(@Valid CalculatorForms.Ohm form, BindingResult bindingResult,
                               Authentication authentication, Model model) {
        if (bindingResult.hasErrors()) {
            return invalidForm("Закон Ома", bindingResult.getFieldErrors().getFirst().getDefaultMessage(), authentication, model);
        }
        try {
            var result = calculators.calculateOhm(authentication.getName(), form.getUnknown(),
                    form.getVoltage(), form.getCurrent(), form.getResistance());
            String unit = switch (form.getUnknown()) {
                case "V" -> "В";
                case "I" -> "А";
                case "R" -> "Ом";
                default -> throw new IllegalArgumentException("Выберите неизвестную величину.");
            };
            model.addAttribute("ohmResult", form.getUnknown() + " = "
                    + result.stripTrailingZeros().toPlainString() + " " + unit);
            return dashboard(authentication, model);
        } catch (IllegalArgumentException exception) {
            return invalidForm("Закон Ома", exception.getMessage(), authentication, model);
        }
    }

    private String invalidForm(String title, String message, Authentication authentication, Model model) {
        model.addAttribute("formErrorTitle", title);
        model.addAttribute("errorMessage", message);
        return dashboard(authentication, model);
    }

    private String dashboard(Authentication authentication, Model model) {
        model.addAttribute("rates", calculators.getRates());
        model.addAttribute("currencyForm", new CalculatorForms.Currency());
        model.addAttribute("ohmForm", new CalculatorForms.Ohm());
        model.addAttribute("username", authentication.getName());
        model.addAttribute("isAdmin", authentication.getAuthorities().stream()
                .anyMatch(authority -> authority.getAuthority().equals("ROLE_ADMIN")));
        return "dashboard";
    }
}
