package app.calculators.web.service;

import app.calculators.web.domain.ExchangeRate;
import app.calculators.web.domain.AdminSetupGuard;
import app.calculators.web.repository.AdminSetupGuardRepository;
import app.calculators.web.repository.ExchangeRateRepository;
import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.ApplicationRunner;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.util.List;

@Component
public class ExchangeRateInitializer implements ApplicationRunner {
    private final ExchangeRateRepository rates;
    private final AdminSetupGuardRepository setupGuards;

    public ExchangeRateInitializer(ExchangeRateRepository rates, AdminSetupGuardRepository setupGuards) {
        this.rates = rates;
        this.setupGuards = setupGuards;
    }

    @Override
    @Transactional
    public void run(ApplicationArguments args) {
        if (!setupGuards.existsById(1)) {
            setupGuards.save(new AdminSetupGuard(1));
        }
        List<ExchangeRate> initialRates = List.of(
                new ExchangeRate("USD", "Доллар США", BigDecimal.ONE, "system"),
                new ExchangeRate("EUR", "Евро", new BigDecimal("0.92"), "system"),
                new ExchangeRate("RUB", "Российский рубль", new BigDecimal("92"), "system"));
        for (ExchangeRate rate : initialRates) {
            if (!rates.existsById(rate.getCode())) {
                rates.save(rate);
            }
        }
    }
}
