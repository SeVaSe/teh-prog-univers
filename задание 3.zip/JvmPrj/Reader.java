import java.util.ArrayList;
import java.util.List;

public class Reader extends Person {
    private String phoneNumber;
    private List<Integer> borrowedBooks;
    
    public Reader(int id, String name, String surname, String patronymic, String address, String phoneNumber) {
        super(id, name, surname, patronymic, address);
        this.phoneNumber = phoneNumber;
        this.borrowedBooks = new ArrayList<>();
    }
    
    public String getPhoneNumber() {
        return phoneNumber;
    }
    
    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }
    
    public void borrowBook(int bookId) {
        if (!borrowedBooks.contains(bookId)) {
            borrowedBooks.add(bookId);
        }
    }
    
    public void returnBook(int bookId) {
        borrowedBooks.remove(Integer.valueOf(bookId));
    }
    
    public List<Integer> getBorrowedBooks() {
        return new ArrayList<>(borrowedBooks);
    }
    
    public int getBorrowedBooksCount() {
        return borrowedBooks.size();
    }
    
    @Override
    public String toString() {
        return super.toString() + " | Телефон: " + phoneNumber + " | Книг взято: " + borrowedBooks.size();
    }
}
