public abstract class Person {
    protected int id;
    protected String name;
    protected String surname;
    protected String patronymic;
    protected String address;
    
    public Person(int id, String name, String surname, String patronymic, String address) {
        this.id = id;
        this.name = name;
        this.surname = surname;
        this.patronymic = patronymic;
        this.address = address;
    }
    
    public int getId() {
        return id;
    }
    
    public String getName() {
        return name;
    }
    
    public String getSurname() {
        return surname;
    }
    
    public String getPatronymic() {
        return patronymic;
    }
    
    public String getAddress() {
        return address;
    }
    
    public void setAddress(String address) {
        this.address = address;
    }
    
    public String getFullName() {
        return surname + " " + name + " " + patronymic;
    }
    
    @Override
    public String toString() {
        return String.format("ID: %d | ФИО: %s | Адрес: %s", id, getFullName(), address);
    }
}