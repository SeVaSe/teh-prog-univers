public class Manager extends Employee {
    
    public Manager(int id, String name, String surname, String patronymic, String address, double salary) {
        super(id, name, surname, patronymic, address, "Менеджер", salary);
    }
}