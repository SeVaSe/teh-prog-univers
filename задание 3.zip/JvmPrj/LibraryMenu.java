import java.util.Scanner;
import java.util.List;

public class LibraryMenu {
    private Library library;
    private Scanner scanner;
    private Employee currentEmployee;
    
    public LibraryMenu() {
        library = new Library();
        scanner = new Scanner(System.in);
        currentEmployee = null;
    }
    
    public void start() {
        loadSampleData();
        
        while (true) {
            if (currentEmployee == null) {
                mainMenu();
            } else if (currentEmployee instanceof Manager) {
                managerMenu();
            } else if (currentEmployee instanceof Librarian) {
                librarianMenu();
            }
        }
    }
    
    private void mainMenu() {
        clearScreen();
        System.out.println("=".repeat(60));
        System.out.println("БИБЛИОТЕКА - ГЛАВНОЕ МЕНЮ");
        System.out.println("=".repeat(60));
        System.out.println("1. Вход сотрудника");
        System.out.println("2. Меню читателя");
        System.out.println("3. Выход");
        System.out.println("=".repeat(60));
        System.out.print("Выберите опцию: ");
        
        int choice = getIntInput();
        
        switch (choice) {
            case 1:
                employeeLogin();
                break;
            case 2:
                readerMenu();
                break;
            case 3:
                exitProgram();
                break;
            default:
                System.out.println("Неверный выбор!");
        }
    }
    
    private void employeeLogin() {
        clearScreen();
        System.out.println("=".repeat(60));
        System.out.println("ВХОД СОТРУДНИКА");
        System.out.println("=".repeat(60));
        System.out.print("Введите ID сотрудника: ");
        int employeeId = getIntInput();
        
        Employee employee = library.findEmployeeById(employeeId);
        if (employee != null) {
            currentEmployee = employee;
            System.out.println("Добро пожаловать, " + employee.getFullName() + "!");
            pause();
        } else {
            System.out.println("Сотрудник не найден!");
            pause();
        }
    }
    
    private void managerMenu() {
        clearScreen();
        System.out.println("=".repeat(60));
        System.out.println("МЕНЮ МЕНЕДЖЕРА");
        System.out.println("Вошли как: " + currentEmployee.getFullName());
        System.out.println("=".repeat(60));
        System.out.println("1. Добавить книгу");
        System.out.println("2. Удалить книгу");
        System.out.println("3. Просмотреть все книги");
        System.out.println("4. Статистика - Всего книг");
        System.out.println("5. Статистика - Книги по категориям");
        System.out.println("6. Статистика - Книги конкретного читателя");
        System.out.println("7. Просмотреть всех читателей");
        System.out.println("8. Добавить читателя");
        System.out.println("9. Добавить сотрудника");
        System.out.println("10. Просмотреть сотрудников");
        System.out.println("11. Выход");
        System.out.println("=".repeat(60));
        System.out.print("Выберите опцию: ");
        
        int choice = getIntInput();
        
        switch (choice) {
            case 1:
                addBook();
                break;
            case 2:
                removeBook();
                break;
            case 3:
                viewAllBooks();
                break;
            case 4:
                statisticsTotalBooks();
                break;
            case 5:
                statisticsBooksByCategory();
                break;
            case 6:
                statisticsReaderBooks();
                break;
            case 7:
                viewAllReaders();
                break;
            case 8:
                addReader();
                break;
            case 9:
                addEmployee();
                break;
            case 10:
                viewAllEmployees();
                break;
            case 11:
                logout();
                break;
            default:
                System.out.println("Неверный выбор!");
        }
        
        pause();
    }
    
    private void librarianMenu() {
        clearScreen();
        System.out.println("=".repeat(60));
        System.out.println("МЕНЮ БИБЛИОТЕЧНОГО РАБОТНИКА");
        System.out.println("Вошли как: " + currentEmployee.getFullName());
        System.out.println("=".repeat(60));
        System.out.println("1. Поиск книги по названию");
        System.out.println("2. Поиск книги по автору");
        System.out.println("3. Поиск книги по категории");
        System.out.println("4. Просмотреть доступные книги");
        System.out.println("5. Выдать книгу читателю");
        System.out.println("6. Принять книгу от читателя");
        System.out.println("7. Просмотреть всех читателей");
        System.out.println("8. Выход");
        System.out.println("=".repeat(60));
        System.out.print("Выберите опцию: ");
        
        int choice = getIntInput();
        
        switch (choice) {
            case 1:
                searchBookByTitle();
                break;
            case 2:
                searchBookByAuthor();
                break;
            case 3:
                searchBookByCategory();
                break;
            case 4:
                viewAvailableBooks();
                break;
            case 5:
                issueBook();
                break;
            case 6:
                returnBookFromReader();
                break;
            case 7:
                viewAllReaders();
                break;
            case 8:
                logout();
                break;
            default:
                System.out.println("Неверный выбор!");
        }
        
        pause();
    }
    
    private void readerMenu() {
        clearScreen();
        System.out.println("=".repeat(60));
        System.out.println("МЕНЮ ЧИТАТЕЛЯ");
        System.out.println("=".repeat(60));
        System.out.print("Введите ваш ID: ");
        int readerId = getIntInput();
        
        Reader reader = library.findReaderById(readerId);
        if (reader == null) {
            System.out.println("Читатель не найден!");
            pause();
            return;
        }
        
        clearScreen();
        System.out.println("=".repeat(60));
        System.out.println("МЕНЮ ЧИТАТЕЛЯ");
        System.out.println("Добро пожаловать, " + reader.getFullName() + "!");
        System.out.println("=".repeat(60));
        System.out.println("1. Мои книги");
        System.out.println("2. Вернуться в главное меню");
        System.out.println("=".repeat(60));
        System.out.print("Выберите опцию: ");
        
        int choice = getIntInput();
        
        switch (choice) {
            case 1:
                viewReaderBooks(readerId);
                break;
            case 2:
                break;
            default:
                System.out.println("Неверный выбор!");
        }
        
        pause();
    }
    
    private void addBook() {
        clearScreen();
        System.out.println("=".repeat(60));
        System.out.println("ДОБАВЛЕНИЕ НОВОЙ КНИГИ");
        System.out.println("=".repeat(60));
        
        System.out.print("ID книги: ");
        int id = getIntInput();
        
        scanner.nextLine();
        
        System.out.print("Название: ");
        String title = scanner.nextLine();
        
        System.out.print("Автор: ");
        String author = scanner.nextLine();
        
        System.out.print("Издание: ");
        int edition = getIntInput();
        scanner.nextLine();
        
        System.out.print("Издатель: ");
        String publisher = scanner.nextLine();
        
        System.out.print("Год издания: ");
        int year = getIntInput();
        scanner.nextLine();
        
        System.out.print("Категория: ");
        String category = scanner.nextLine();
        
        Book book = new Book(id, title, author, edition, publisher, year, category);
        if (library.addBook(book)) {
            System.out.println("Книга успешно добавлена!");
        } else {
            System.out.println("Ошибка при добавлении книги!");
        }
    }
    
    private void removeBook() {
        clearScreen();
        System.out.println("=".repeat(60));
        System.out.println("УДАЛЕНИЕ КНИГИ");
        System.out.println("=".repeat(60));
        System.out.print("Введите ID книги для удаления: ");
        int bookId = getIntInput();
        
        if (library.removeBook(bookId)) {
            System.out.println("Книга успешно удалена!");
        } else {
            System.out.println("Книга не найдена!");
        }
    }
    
    private void viewAllBooks() {
        clearScreen();
        System.out.println("=".repeat(60));
        System.out.println("ВСЕ КНИГИ В БИБЛИОТЕКЕ");
        System.out.println("=".repeat(60));
        
        List<Book> books = library.getAllBooks();
        if (books.isEmpty()) {
            System.out.println("Книг не найдено!");
        } else {
            for (Book book : books) {
                System.out.println(book);
                System.out.println("-".repeat(60));
            }
        }
    }
    
    private void viewAvailableBooks() {
        clearScreen();
        System.out.println("=".repeat(60));
        System.out.println("ДОСТУПНЫЕ КНИГИ");
        System.out.println("=".repeat(60));
        
        List<Book> books = library.getAvailableBooks();
        if (books.isEmpty()) {
            System.out.println("Доступных книг не найдено!");
        } else {
            for (Book book : books) {
                System.out.println(book);
                System.out.println("-".repeat(60));
            }
        }
    }
    
    private void statisticsTotalBooks() {
        clearScreen();
        System.out.println("=".repeat(60));
        System.out.println("СТАТИСТИКА КНИГ");
        System.out.println("=".repeat(60));
        System.out.println("Всего книг: " + library.getTotalBooks());
        System.out.println("Доступных книг: " + library.getAvailableBooksCount());
        System.out.println("Выданных книг: " + library.getBorrowedBooksCount());
        System.out.println("=".repeat(60));
    }
    
    private void statisticsBooksByCategory() {
        clearScreen();
        System.out.println("=".repeat(60));
        System.out.println("СТАТИСТИКА ПО КАТЕГОРИЯМ");
        System.out.println("=".repeat(60));
        
        List<String> categories = library.getAllCategories();
        for (String category : categories) {
            System.out.println(category + ": " + library.getCategoryBookCount(category) + " книг(и)");
        }
        System.out.println("=".repeat(60));
    }
    
    private void statisticsReaderBooks() {
        clearScreen();
        System.out.println("=".repeat(60));
        System.out.println("КНИГИ КОНКРЕТНОГО ЧИТАТЕЛЯ");
        System.out.println("=".repeat(60));
        System.out.print("Введите ID читателя: ");
        int readerId = getIntInput();
        
        Reader reader = library.findReaderById(readerId);
        if (reader == null) {
            System.out.println("Читатель не найден!");
            return;
        }
        
        System.out.println("\nКниги читателя: " + reader.getFullName());
        System.out.println("-".repeat(60));
        
        List<Book> books = library.getReaderBooks(readerId);
        if (books.isEmpty()) {
            System.out.println("У этого читателя нет книг!");
        } else {
            for (Book book : books) {
                System.out.println(book);
                System.out.println("-".repeat(60));
            }
        }
    }
    
    private void searchBookByTitle() {
        clearScreen();
        System.out.println("=".repeat(60));
        System.out.println("ПОИСК КНИГИ ПО НАЗВАНИЮ");
        System.out.println("=".repeat(60));
        
        scanner.nextLine();
        System.out.print("Введите название книги: ");
        String title = scanner.nextLine();
        
        List<Book> books = library.findBooksByTitle(title);
        if (books.isEmpty()) {
            System.out.println("Книги не найдены!");
        } else {
            System.out.println("=".repeat(60));
            for (Book book : books) {
                System.out.println(book);
                System.out.println("-".repeat(60));
            }
        }
    }
    
    private void searchBookByAuthor() {
        clearScreen();
        System.out.println("=".repeat(60));
        System.out.println("ПОИСК КНИГИ ПО АВТОРУ");
        System.out.println("=".repeat(60));
        
        scanner.nextLine();
        System.out.print("Введите имя автора: ");
        String author = scanner.nextLine();
        
        List<Book> books = library.findBooksByAuthor(author);
        if (books.isEmpty()) {
            System.out.println("Книги не найдены!");
        } else {
            System.out.println("=".repeat(60));
            for (Book book : books) {
                System.out.println(book);
                System.out.println("-".repeat(60));
            }
        }
    }
    
    private void searchBookByCategory() {
        clearScreen();
        System.out.println("=".repeat(60));
        System.out.println("ПОИСК КНИГИ ПО КАТЕГОРИИ");
        System.out.println("=".repeat(60));
        
        List<String> categories = library.getAllCategories();
        if (categories.isEmpty()) {
            System.out.println("Категорий не найдено!");
            return;
        }
        
        System.out.println("Доступные категории:");
        for (int i = 0; i < categories.size(); i++) {
            System.out.println((i + 1) + ". " + categories.get(i));
        }
        System.out.print("Выберите категорию (номер): ");
        int choice = getIntInput();
        
        if (choice > 0 && choice <= categories.size()) {
            String category = categories.get(choice - 1);
            List<Book> books = library.findBooksByCategory(category);
            
            System.out.println("=".repeat(60));
            for (Book book : books) {
                System.out.println(book);
                System.out.println("-".repeat(60));
            }
        } else {
            System.out.println("Неверный выбор!");
        }
    }
    
    private void issueBook() {
        clearScreen();
        System.out.println("=".repeat(60));
        System.out.println("ВЫДАЧА КНИГИ ЧИТАТЕЛЮ");
        System.out.println("=".repeat(60));
        System.out.print("Введите ID книги: ");
        int bookId = getIntInput();
        
        System.out.print("Введите ID читателя: ");
        int readerId = getIntInput();
        
        if (library.borrowBook(bookId, readerId)) {
            System.out.println("Книга успешно выдана!");
        } else {
            System.out.println("Ошибка при выдаче книги!");
        }
    }
    
    private void returnBookFromReader() {
        clearScreen();
        System.out.println("=".repeat(60));
        System.out.println("ВОЗВРАТ КНИГИ ОТ ЧИТАТЕЛЯ");
        System.out.println("=".repeat(60));
        System.out.print("Введите ID книги: ");
        int bookId = getIntInput();
        
        System.out.print("Введите ID читателя: ");
        int readerId = getIntInput();
        
        if (library.returnBook(bookId, readerId)) {
            System.out.println("Книга успешно принята!");
        } else {
            System.out.println("Ошибка при приеме книги!");
        }
    }
    
    private void viewAllReaders() {
        clearScreen();
        System.out.println("=".repeat(60));
        System.out.println("ВСЕ ЧИТАТЕЛИ");
        System.out.println("=".repeat(60));
        
        List<Reader> readers = library.getAllReaders();
        if (readers.isEmpty()) {
            System.out.println("Читателей не найдено!");
        } else {
            for (Reader reader : readers) {
                System.out.println(reader);
                System.out.println("-".repeat(60));
            }
        }
    }
    
    private void viewReaderBooks(int readerId) {
        clearScreen();
        System.out.println("=".repeat(60));
        System.out.println("МОИ КНИГИ");
        System.out.println("=".repeat(60));
        
        List<Book> books = library.getReaderBooks(readerId);
        if (books.isEmpty()) {
            System.out.println("У вас нет книг!");
        } else {
            for (Book book : books) {
                System.out.println(book);
                System.out.println("-".repeat(60));
            }
        }
    }
    
    private void addReader() {
        clearScreen();
        System.out.println("=".repeat(60));
        System.out.println("ДОБАВЛЕНИЕ НОВОГО ЧИТАТЕЛЯ");
        System.out.println("=".repeat(60));
        
        System.out.print("ID читателя: ");
        int id = getIntInput();
        scanner.nextLine();
        
        System.out.print("Имя: ");
        String name = scanner.nextLine();
        
        System.out.print("Фамилия: ");
        String surname = scanner.nextLine();
        
        System.out.print("Отчество: ");
        String patronymic = scanner.nextLine();
        
        System.out.print("Адрес: ");
        String address = scanner.nextLine();
        
        System.out.print("Номер телефона: ");
        String phone = scanner.nextLine();
        
        Reader reader = new Reader(id, name, surname, patronymic, address, phone);
        if (library.addReader(reader)) {
            System.out.println("Читатель успешно добавлен!");
        } else {
            System.out.println("Ошибка при добавлении читателя!");
        }
    }
    
    private void addEmployee() {
        clearScreen();
        System.out.println("=".repeat(60));
        System.out.println("ДОБАВЛЕНИЕ НОВОГО СОТРУДНИКА");
        System.out.println("=".repeat(60));
        System.out.println("1. Менеджер");
        System.out.println("2. Библиотечный работник");
        System.out.print("Выберите должность: ");
        
        int roleChoice = getIntInput();
        scanner.nextLine();
        
        System.out.print("ID сотрудника: ");
        int id = getIntInput();
        scanner.nextLine();
        
        System.out.print("Имя: ");
        String name = scanner.nextLine();
        
        System.out.print("Фамилия: ");
        String surname = scanner.nextLine();
        
        System.out.print("Отчество: ");
        String patronymic = scanner.nextLine();
        
        System.out.print("Адрес: ");
        String address = scanner.nextLine();
        
        System.out.print("Зарплата: ");
        double salary = getDoubleInput();
        
        Employee employee = null;
        if (roleChoice == 1) {
            employee = new Manager(id, name, surname, patronymic, address, salary);
        } else if (roleChoice == 2) {
            employee = new Librarian(id, name, surname, patronymic, address, salary);
        }
        
        if (employee != null && library.addEmployee(employee)) {
            System.out.println("Сотрудник успешно добавлен!");
        } else {
            System.out.println("Ошибка при добавлении сотрудника!");
        }
    }
    
    private void viewAllEmployees() {
        clearScreen();
        System.out.println("=".repeat(60));
        System.out.println("ВСЕ СОТРУДНИКИ");
        System.out.println("=".repeat(60));
        
        List<Employee> employees = library.getAllEmployees();
        if (employees.isEmpty()) {
            System.out.println("Сотрудников не найдено!");
        } else {
            for (Employee employee : employees) {
                System.out.println(employee);
                System.out.println("-".repeat(60));
            }
        }
    }
    
    private void logout() {
        System.out.println("Вы вышли из системы!");
        currentEmployee = null;
    }
    
    private void exitProgram() {
        System.out.println("\nСохранение данных...");
        library.saveToFiles();
        System.out.println("До встречи!");
        System.exit(0);
    }
    
    private void loadSampleData() {
        if (library.getTotalBooks() == 0) {
            library.addBook(new Book(1, "Война и мир", "Лев Толстой", 1, "Детский мир", 1869, "Роман"));
            library.addBook(new Book(2, "Преступление и наказание", "Федор Достоевский", 1, "Эксмо", 1866, "Роман"));
            library.addBook(new Book(3, "Мастер и Маргарита", "Михаил Булгаков", 1, "Бертельсман", 1967, "Роман"));
            library.addBook(new Book(4, "1984", "Джордж Оруэлл", 1, "Penguin", 1949, "Научная фантастика"));
            library.addBook(new Book(5, "Граф Монте-Кристо", "Александр Дюма", 1, "Пальмира", 1844, "Приключения"));
            
            library.addReader(new Reader(1, "Иван", "Петров", "Иванович", "Москва, ул. Ленина 1", "89991234567"));
            library.addReader(new Reader(2, "Мария", "Сидорова", "Сергеевна", "Санкт-Петербург, ул. Невского 5", "89995678901"));
            library.addReader(new Reader(3, "Петр", "Иванов", "Петрович", "Казань, ул. Петербургская 10", "89997654321"));
            
            library.addEmployee(new Manager(1, "Алексей", "Смирнов", "Александрович", "Москва, ул. Баумана 3", 75000));
            library.addEmployee(new Librarian(2, "Анна", "Козлова", "Ивановна", "Москва, ул. Красного Октября 7", 45000));
            library.addEmployee(new Librarian(3, "Сергей", "Волков", "Сергеевич", "Москва, ул. Горького 2", 45000));
            
            library.saveToFiles();
        }
    }
    
    private int getIntInput() {
        try {
            return scanner.nextInt();
        } catch (Exception e) {
            scanner.nextLine();
            return -1;
        }
    }
    
    private double getDoubleInput() {
        try {
            return scanner.nextDouble();
        } catch (Exception e) {
            scanner.nextLine();
            return -1;
        }
    }
    
    private void pause() {
        System.out.println("\nНажмите Enter для продолжения...");
        scanner.nextLine();
        scanner.nextLine();
    }
    
    private void clearScreen() {
        System.out.println("\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n");
    }
}
