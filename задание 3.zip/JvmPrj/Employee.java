public abstract class Employee extends Person {
    protected String position;
    protected double salary;
    
    public Employee(int id, String name, String surname, String patronymic, String address, 
                   String position, double salary) {
        super(id, name, surname, patronymic, address);
        this.position = position;
        this.salary = salary;
    }
    
    public String getPosition() {
        return position;
    }
    
    public double getSalary() {
        return salary;
    }
    
    public void setSalary(double salary) {
        this.salary = salary;
    }
    
    @Override
    public String toString() {
        return super.toString() + " | Должность: " + position + " | Зарплата: " + salary;
    }
}
