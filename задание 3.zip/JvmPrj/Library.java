import java.util.ArrayList;
import java.util.List;
import java.io.*;

public class Library {
    private List<Book> books;
    private List<Reader> readers;
    private List<Employee> employees;
    private static final String BOOKS_FILE = "books.txt";
    private static final String READERS_FILE = "readers.txt";
    private static final String EMPLOYEES_FILE = "employees.txt";
    private static final String BORROWED_FILE = "borrowed.txt";
    
    public Library() {
        this.books = new ArrayList<>();
        this.readers = new ArrayList<>();
        this.employees = new ArrayList<>();
        loadFromFiles();
    }
    
    public boolean addBook(Book book) {
        return books.add(book);
    }
    
    public boolean removeBook(int bookId) {
        return books.removeIf(b -> b.getId() == bookId);
    }
    
    public Book findBookById(int bookId) {
        return books.stream().filter(b -> b.getId() == bookId).findFirst().orElse(null);
    }
    
    public List<Book> findBooksByTitle(String title) {
        List<Book> result = new ArrayList<>();
        for (Book b : books) {
            if (b.getTitle().toLowerCase().contains(title.toLowerCase())) {
                result.add(b);
            }
        }
        return result;
    }
    
    public List<Book> findBooksByAuthor(String author) {
        List<Book> result = new ArrayList<>();
        for (Book b : books) {
            if (b.getAuthor().toLowerCase().contains(author.toLowerCase())) {
                result.add(b);
            }
        }
        return result;
    }
    
    public List<Book> findBooksByCategory(String category) {
        List<Book> result = new ArrayList<>();
        for (Book b : books) {
            if (b.getCategory().equalsIgnoreCase(category)) {
                result.add(b);
            }
        }
        return result;
    }
    
    public List<Book> getAvailableBooks() {
        List<Book> result = new ArrayList<>();
        for (Book b : books) {
            if (b.isAvailable()) {
                result.add(b);
            }
        }
        return result;
    }
    
    public boolean addReader(Reader reader) {
        return readers.add(reader);
    }
    
    public boolean removeReader(int readerId) {
        return readers.removeIf(r -> r.getId() == readerId);
    }
    
    public Reader findReaderById(int readerId) {
        return readers.stream().filter(r -> r.getId() == readerId).findFirst().orElse(null);
    }
    
    public List<Reader> getAllReaders() {
        return new ArrayList<>(readers);
    }
    
    public boolean addEmployee(Employee employee) {
        return employees.add(employee);
    }
    
    public boolean removeEmployee(int employeeId) {
        return employees.removeIf(e -> e.getId() == employeeId);
    }
    
    public Employee findEmployeeById(int employeeId) {
        return employees.stream().filter(e -> e.getId() == employeeId).findFirst().orElse(null);
    }
    
    public List<Employee> getAllEmployees() {
        return new ArrayList<>(employees);
    }
    
    public boolean borrowBook(int bookId, int readerId) {
        Book book = findBookById(bookId);
        Reader reader = findReaderById(readerId);
        
        if (book == null || reader == null) {
            return false;
        }
        
        if (!book.isAvailable()) {
            return false;
        }
        
        book.setAvailable(false);
        book.setBorrowedBy(readerId);
        reader.borrowBook(bookId);
        
        return true;
    }
    
    public boolean returnBook(int bookId, int readerId) {
        Book book = findBookById(bookId);
        Reader reader = findReaderById(readerId);
        
        if (book == null || reader == null) {
            return false;
        }
        
        if (book.isAvailable()) {
            return false;
        }
        
        book.setAvailable(true);
        book.setBorrowedBy(-1);
        reader.returnBook(bookId);
        
        return true;
    }
    
    public int getTotalBooks() {
        return books.size();
    }
    
    public int getAvailableBooksCount() {
        return (int) books.stream().filter(Book::isAvailable).count();
    }
    
    public int getBorrowedBooksCount() {
        return getTotalBooks() - getAvailableBooksCount();
    }
    
    public int getCategoryBookCount(String category) {
        return (int) books.stream().filter(b -> b.getCategory().equalsIgnoreCase(category)).count();
    }
    
    public List<Book> getReaderBooks(int readerId) {
        Reader reader = findReaderById(readerId);
        List<Book> result = new ArrayList<>();
        
        if (reader != null) {
            for (int bookId : reader.getBorrowedBooks()) {
                Book book = findBookById(bookId);
                if (book != null) {
                    result.add(book);
                }
            }
        }
        
        return result;
    }
    
    public List<String> getAllCategories() {
        List<String> categories = new ArrayList<>();
        for (Book b : books) {
            if (!categories.contains(b.getCategory())) {
                categories.add(b.getCategory());
            }
        }
        return categories;
    }
    
    public List<Book> getAllBooks() {
        return new ArrayList<>(books);
    }
    
    public void saveToFiles() {
        saveBooks();
        saveReaders();
        saveEmployees();
        saveBorrowed();
    }
    
    private void saveBooks() {
        try (PrintWriter writer = new PrintWriter(new FileWriter(BOOKS_FILE))) {
            for (Book book : books) {
                writer.printf("%d|%s|%s|%d|%s|%d|%s|%b|%d\n",
                        book.getId(), book.getTitle(), book.getAuthor(),
                        book.getEdition(), book.getPublisher(), book.getYearPublished(),
                        book.getCategory(), book.isAvailable(), book.getBorrowedBy());
            }
        } catch (IOException e) {
            System.out.println("Ошибка при сохранении книг: " + e.getMessage());
        }
    }
    
    private void saveReaders() {
        try (PrintWriter writer = new PrintWriter(new FileWriter(READERS_FILE))) {
            for (Reader reader : readers) {
                writer.printf("%d|%s|%s|%s|%s|%s\n",
                        reader.getId(), reader.getName(), reader.getSurname(),
                        reader.getPatronymic(), reader.getAddress(), reader.getPhoneNumber());
            }
        } catch (IOException e) {
            System.out.println("Ошибка при сохранении читателей: " + e.getMessage());
        }
    }
    
    private void saveEmployees() {
        try (PrintWriter writer = new PrintWriter(new FileWriter(EMPLOYEES_FILE))) {
            for (Employee employee : employees) {
                String type = employee instanceof Manager ? "MANAGER" : "LIBRARIAN";
                writer.printf("%s|%d|%s|%s|%s|%s|%.2f\n",
                        type, employee.getId(), employee.getName(), employee.getSurname(),
                        employee.getPatronymic(), employee.getAddress(), employee.getSalary());
            }
        } catch (IOException e) {
            System.out.println("Ошибка при сохранении сотрудников: " + e.getMessage());
        }
    }
    
    private void saveBorrowed() {
        try (PrintWriter writer = new PrintWriter(new FileWriter(BORROWED_FILE))) {
            for (Reader reader : readers) {
                for (int bookId : reader.getBorrowedBooks()) {
                    writer.printf("%d|%d\n", reader.getId(), bookId);
                }
            }
        } catch (IOException e) {
            System.out.println("Ошибка при сохранении выданных книг: " + e.getMessage());
        }
    }
    
    private void loadFromFiles() {
        loadBooks();
        loadReaders();
        loadEmployees();
        loadBorrowed();
    }
    
    private void loadBooks() {
        File file = new File(BOOKS_FILE);
        if (!file.exists()) return;
        
        try (BufferedReader reader = new BufferedReader(new FileReader(BOOKS_FILE))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] parts = line.split("\\|");
                if (parts.length >= 7) {
                    int id = Integer.parseInt(parts[0]);
                    String title = parts[1];
                    String author = parts[2];
                    int edition = Integer.parseInt(parts[3]);
                    String publisher = parts[4];
                    int year = Integer.parseInt(parts[5]);
                    String category = parts[6];
                    
                    Book book = new Book(id, title, author, edition, publisher, year, category);
                    if (parts.length > 7) {
                        book.setAvailable(Boolean.parseBoolean(parts[7]));
                    }
                    if (parts.length > 8) {
                        book.setBorrowedBy(Integer.parseInt(parts[8]));
                    }
                    books.add(book);
                }
            }
        } catch (IOException e) {
            System.out.println("Ошибка при загрузке книг: " + e.getMessage());
        }
    }
    
    private void loadReaders() {
        File file = new File(READERS_FILE);
        if (!file.exists()) return;
        
        try (BufferedReader reader = new BufferedReader(new FileReader(READERS_FILE))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] parts = line.split("\\|");
                if (parts.length >= 6) {
                    int id = Integer.parseInt(parts[0]);
                    String name = parts[1];
                    String surname = parts[2];
                    String patronymic = parts[3];
                    String address = parts[4];
                    String phone = parts[5];
                    
                    readers.add(new Reader(id, name, surname, patronymic, address, phone));
                }
            }
        } catch (IOException e) {
            System.out.println("Ошибка при загрузке читателей: " + e.getMessage());
        }
    }
    
    private void loadEmployees() {
        File file = new File(EMPLOYEES_FILE);
        if (!file.exists()) return;
        
        try (BufferedReader reader = new BufferedReader(new FileReader(EMPLOYEES_FILE))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] parts = line.split("\\|");
                if (parts.length >= 7) {
                    String type = parts[0];
                    int id = Integer.parseInt(parts[1]);
                    String name = parts[2];
                    String surname = parts[3];
                    String patronymic = parts[4];
                    String address = parts[5];
                    double salary = Double.parseDouble(parts[6]);
                    
                    if ("MANAGER".equals(type)) {
                        employees.add(new Manager(id, name, surname, patronymic, address, salary));
                    } else {
                        employees.add(new Librarian(id, name, surname, patronymic, address, salary));
                    }
                }
            }
        } catch (IOException e) {
            System.out.println("Ошибка при загрузке сотрудников: " + e.getMessage());
        }
    }
    
    private void loadBorrowed() {
        File file = new File(BORROWED_FILE);
        if (!file.exists()) return;
        
        try (BufferedReader reader = new BufferedReader(new FileReader(BORROWED_FILE))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] parts = line.split("\\|");
                if (parts.length == 2) {
                    int readerId = Integer.parseInt(parts[0]);
                    int bookId = Integer.parseInt(parts[1]);
                    Reader reader_obj = findReaderById(readerId);
                    if (reader_obj != null) {
                        reader_obj.borrowBook(bookId);
                    }
                }
            }
        } catch (IOException e) {
            System.out.println("Ошибка при загрузке выданных книг: " + e.getMessage());
        }
    }
}
