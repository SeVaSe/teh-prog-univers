public class Book {
    private int id;
    private String title;
    private String author;
    private int edition;
    private String publisher;
    private int yearPublished;
    private String category;
    private boolean available;
    private int borrowedBy;
    
    public Book(int id, String title, String author, int edition, String publisher, 
                int yearPublished, String category) {
        this.id = id;
        this.title = title;
        this.author = author;
        this.edition = edition;
        this.publisher = publisher;
        this.yearPublished = yearPublished;
        this.category = category;
        this.available = true;
        this.borrowedBy = -1;
    }
    
    public int getId() {
        return id;
    }
    
    public String getTitle() {
        return title;
    }
    
    public String getAuthor() {
        return author;
    }
    
    public int getEdition() {
        return edition;
    }
    
    public String getPublisher() {
        return publisher;
    }
    
    public int getYearPublished() {
        return yearPublished;
    }
    
    public String getCategory() {
        return category;
    }
    
    public boolean isAvailable() {
        return available;
    }
    
    public void setAvailable(boolean available) {
        this.available = available;
    }
    
    public int getBorrowedBy() {
        return borrowedBy;
    }
    
    public void setBorrowedBy(int readerId) {
        this.borrowedBy = readerId;
    }
    
    @Override
    public String toString() {
        String status = available ? "В наличии" : "Выдана";
        return String.format("ID: %d | %s | Автор: %s | %d изд. | %s | %d г. | Категория: %s | Статус: %s",
                id, title, author, edition, publisher, yearPublished, category, status);
    }
}
