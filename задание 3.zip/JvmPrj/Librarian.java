public class Librarian extends Employee {
    
    public Librarian(int id, String name, String surname, String patronymic, String address, double salary) {
        super(id, name, surname, patronymic, address, "Библиотечный работник", salary);
    }
}